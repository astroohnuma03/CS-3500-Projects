Assignment 6, 11/23/22

Completed:
- Ability to load and save conventional file formats and ASCII ppm files
- Blur, Brightness, Flip, Grayscale (Component and Color Transformation), Sepia, Value/Intensity/Luma visualization, and Sharpen image modification commands
- List command to return a list of the files in the processor
- Ability to operate program with script files
- Ability to accept a script file as a command-line option
- Ability to display Image Processing in a graphical interface which uses buttons to apply
different image processing effects to a loaded image
- Ability to switch between images in the graphical interface
- Shows histogram of RGB pixel values for current image in the graphical interface
- All previous methods possible in graphical interface

Design Changes:
- Save method has now been refactored to be a method of the view. This was done to avoid
using I/O methods in the model as recommended by a TA. Save works the exact same and is run
through the controller and command-line the same, its just that the view is now the one
controlling the method.
- GUI Controller was added to allow the GUI to have its own controller since it gets very
complicated
- Replace image and remove image were added to the model as well as create256Map and create
RGB list being added to the image class. Pixel now has methods to get each of its rgb components
- GUI View added along with its class, mock version, and test file
- Interface of features called GUIView actions along with all its function objects were added
to allow the GUI to use the model methods
- A custom JPanel called HistogramPanel was added which visualizes a histogram of the current
image's RGB values and their frequencies as well as intensity
- ImageProcessor has been split so it can now run a text file, run like in the last assignment
, and run with the graphical interface