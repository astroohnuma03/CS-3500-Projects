Assignment 4: Image Processing (Part 1)

Submitted November 3rd, 2022

~~~~~

File Instructions:

Start the program by running the public static void main method in the file ImageProcessor in the main package. For the purpose of demonstration, do the following:

- load [File Path] [Image Name]

Use the load command, enter res/CuyValleyOriginal.ppm, CuyValley as arguments to load a file into the program.

- grayscale [red/green/blue] [Old Image Name] [New Image Name]

Use the grayscale command, enter red, CuyValley, GrayValley as arguments to create a grayscaled version of the file you loaded.

- brightness [Amount] [Old Image Name] [New Image Name]

Use the brightness command, enter 50, GrayValley, BrightValley as arguments to create a brighter version of the grayscale you made.

- flip [horizontal/vertical] [Old Image Name] [New Image Name]

Use the flip command, enter horizontal, BrightValley, FlipValley as arguments to create a flipped version of the brighter image you made.

- save [File Path] [Image Name] - Save an image from the program under the given file path. Include name and file extension in file path.

Save your creation by entering the arguments res/MyImage.ppm, FlipValley.

- list

Before you leave, use the list command to see the names of all the images you have created.

- quit/q

To exit the program, type quit or q. Now you know how to use the image processor!

~~~~~

Image Citation:

Eric Drost, "Cuyahoga Valley National Park." Wikimedia Commons, 18 Oct. 2013, <https://commons.wikimedia.org/wiki/File:Cuyahoga_Valley_National_Park_(10355384194).jpg>

Licensed under CC BY 2.0 <https://creativecommons.org/licenses/by/2.0>

All images in res/TestImages were created by Thomas Vodrey, and have been authorized for use in this project.

~~~~~

Design Explanation:

Interface ImageProcessingController
- The controller of the program, handles input and refers it to the model.

Class ImageProcessingControllerImpl
- Implemenatation of ImageProcessingController, allows the calling of commands by the user or a specified input.

~~~

Interface ImageProcessingModel
- The model of the program, implements all of the program's functionality. Stores images.

Class ImageProcessingModelImpl
- Model which stores images and allows the use of commands on those images. Implements ImageProcessingModel.

Class ImageProcessingMockModel
- Mock model for testing the ability of the controller to send inputs to the model. Implements ImageProcessingModel.

~~~

Class ImageUtil
- Contains utility methods to read a PPM image from a file and process it.

Class Image
- Represents an image made up of pixels

Class Pixel
- Represents a single pixel made of red, green, and blue color values.

~~~

Interface ImageProcessingCommand
- Represents an action which can be executed upon the program's model.

Class LoadImage
- Loads an image from a file path into the model. Implements ImageProcessingCommand.

Class SaveImage
- Saves an image from the model to a file path. Implements ImageProcessingCommand.

Class List
- Displays a list of the images saved to the model. Implements ImageProcessingCommand.

Class CreateGrayScale
- Creates a new version of an image without any color, using a specific color component. Implements ImageProcessingCommand.

Class CreateVILImage
- Creates a new version of an image visualizing the value, intensity, or luma of it. Implements ImageProcessingCommand.

Class CreateFlippedImage
- Creates a new version of an image that is flipped either vertically or horizontally. Implements ImageProcessingCommand.

Class CreateBrightnessImage
- Creates a new version of an image that is either darker or brighter by a specified amount. Implements ImageProcessingCommand.

~~~

Interface ImageProcessingView
- The view of the program, handles displaying results to the user.

Class ImageProcessingViewImpl
- Implementation of ImageProcessingView, provides a means to communicate with the user or a specified output.
