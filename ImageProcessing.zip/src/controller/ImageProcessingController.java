package controller;

/**
 * This interface represents the controller for the image processing model and allows a user to
 * load, save, and modify images through various commands.
 */
public interface ImageProcessingController {

  /**
   * Run a new instance of the image processing controller.
   */
  void runProgram();
}
