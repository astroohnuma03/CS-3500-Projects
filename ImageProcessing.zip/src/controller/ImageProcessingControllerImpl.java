package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;

import model.commands.Blur;
import model.commands.CreateBrightnessImage;
import model.commands.CreateFlippedImage;
import model.commands.CreateGrayscale;
import model.commands.CreateSepiaImage;
import model.commands.CreateTransformGrayscale;
import model.commands.CreateVILImage;
import model.commands.ImageProcessingCommand;
import model.ImageProcessingModel;
import model.commands.ListImages;
import model.commands.LoadImage;
import model.commands.SaveImage;
import model.commands.Sharpen;
import view.ImageProcessingView;

/**
 * Class which represents the controller for the image processing model.
 */
public class ImageProcessingControllerImpl implements ImageProcessingController {

  private ImageProcessingModel model;
  private ImageProcessingView view;
  private Readable input;

  private Map<String, Function<Scanner, ImageProcessingCommand>> knownCommands;

  /**
   * Default constructor for the image processing controller which takes in a model, view, and
   * readable input to create a controller.
   *
   * @param model The model the controller will use
   * @param view  The view the controller will use
   * @param input The input the controller will read from
   */
  public ImageProcessingControllerImpl(ImageProcessingModel model, ImageProcessingView view,
                                        Readable input) {
    if (model == null) {
      throw new IllegalArgumentException("Provided model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("Provided view cannot be null");
    }
    if (input == null) {
      throw new IllegalArgumentException("Provided input cannot be null");
    }

    this.model = model;
    this.view = view;
    this.input = input;

    // Add commands to list of known commands
    this.knownCommands = new HashMap<>();

    // load [File Path] [New Image Name]
    this.knownCommands.put("load", s -> new LoadImage(s.next(), s.next()));
    // save [File Path] [Image Name]
    this.knownCommands.put("save", s -> new SaveImage(s.next(), s.next()));
    // grayscale [red/green/blue] [Image Name] [New Image Name]
    this.knownCommands.put("grayscale", s -> new CreateGrayscale(s.next(), s.next(), s.next()));
    // vilImage [value/intensity/luma] [Image Name] [New Image Name]
    this.knownCommands.put("vilImage", s -> new CreateVILImage(s.next(), s.next(), s.next()));
    // flip [vertical/horizontal] [Image Name] [New Image Name]
    this.knownCommands.put("flip", s -> new CreateFlippedImage(s.next(), s.next(), s.next()));
    // brightness [Increment] [Image Name] [New Image Name]
    this.knownCommands.put("brightness",
        s -> new CreateBrightnessImage(s.nextInt(), s.next(), s.next()));
    // list
    this.knownCommands.put("list", s -> new ListImages());
    // blur [Image Name] [New Image Name]
    this.knownCommands.put("blur", s -> new Blur(s.next(), s.next()));
    // sharpen [Image Name] [New Image Name]
    this.knownCommands.put("sharpen", s -> new Sharpen(s.next(), s.next()));
    // sepia [Image Name] [New Image Name]
    this.knownCommands.put("sepia", s -> new CreateSepiaImage(s.next(), s.next()));
    // grayscaleTransform [Image Name] [New Image Name]
    this.knownCommands.put("grayscaleTransform",
        s -> new CreateTransformGrayscale(s.next(), s.next()));
  }

  /**
   * Run a new instance of the image processing controller.
   */
  @Override
  public void runProgram() {
    Scanner scan = new Scanner(this.input);

    while (scan.hasNext()) {
      ImageProcessingCommand c;

      String in = scan.next();

      // Quit game
      if (in.equalsIgnoreCase("q") || in.equalsIgnoreCase("quit")) {
        return;
      }

      // Run command
      Function<Scanner, ImageProcessingCommand> cmd = this.knownCommands.getOrDefault(in,
              null);

      if (cmd == null) {
        try {
          this.view.renderMessage("Invalid command. Try again.");
        } catch (IOException e) {
          throw new IllegalStateException("Appendable failed.");
        }

      } else {
        c = cmd.apply(scan);
        c.runCommand(this.model, this.view);
      }
    }
  }
}
