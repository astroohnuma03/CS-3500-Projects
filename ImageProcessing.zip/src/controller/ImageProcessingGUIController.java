package controller;

/**
 * This interface represents the controller for the image processing model using a graphical
 * interface that allows loading, visualizing, modifying, and saving images.
 */
public interface ImageProcessingGUIController extends ImageProcessingController {

  /**
   * Run the given command.
   *
   * @param command The command to run given as a string
   */
  void runCommand(String command);
}
