package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JComboBox;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;
import view.features.BlurAction;
import view.features.BrightenImageAction;
import view.features.FlipImageAction;
import view.features.GrayscaleImageAction;
import view.features.ImageProcessingGUIViewActions;
import view.features.ImageSelectionAction;
import view.features.ListImageAction;
import view.features.LoadImageAction;
import view.features.SaveImageAction;
import view.features.SepiaImageAction;
import view.features.SharpenAction;
import view.features.TransformGrayscaleImageAction;
import view.features.VILImageAction;

/**
 * Class which represents the controller for the image processing model using a graphical interface.
 */
public class ImageProcessingGUIControllerImpl implements ImageProcessingGUIController,
        ActionListener {
  private ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private Map<String, ImageProcessingGUIViewActions> knownCommands;

  /**
   * Default constructor for the image processing model using a graphical interface which takes in
   * a model and view to create a controller.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public ImageProcessingGUIControllerImpl(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }

    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.model = model;
    this.view = view;

    this.knownCommands = new HashMap<>();

    this.knownCommands.put("Load", new LoadImageAction(this.model, this.view));

    this.knownCommands.put("Save", new SaveImageAction(this.model, this.view));

    this.knownCommands.put("Grayscale", new GrayscaleImageAction(this.model,
            this.view));

    this.knownCommands.put("Transform Grayscale", new TransformGrayscaleImageAction(this.model,
            this.view));

    this.knownCommands.put("VIL", new VILImageAction(this.model, this.view));

    this.knownCommands.put("Flip", new FlipImageAction(this.model, this.view));

    this.knownCommands.put("Brighten", new BrightenImageAction(this.model, this.view));

    this.knownCommands.put("List", new ListImageAction(this.model, this.view));

    this.knownCommands.put("Blur", new BlurAction(this.model, this.view));

    this.knownCommands.put("Sharpen", new SharpenAction(this.model, this.view));

    this.knownCommands.put("Sepia", new SepiaImageAction(this.model, this.view));
  }

  /**
   * Constructor which takes in a model, view, and a map of knownCommands which can be customized
   * rather than using the default ones.
   *
   * @param model         The model to use
   * @param view          The view to use
   * @param knownCommands The commands the controller should respond to
   */
  public ImageProcessingGUIControllerImpl(ImageProcessingModel model, ImageProcessingGUIView view,
                                          Map<String, ImageProcessingGUIViewActions>
                                                  knownCommands) {
    this.model = model;
    this.view = view;
    this.knownCommands = knownCommands;
  }

  @Override
  public void runProgram() {
    this.view.setListener(this);
    this.view.makeVisible();
  }

  @Override
  public void runCommand(String command) {
    ImageProcessingGUIViewActions c;

    c = this.knownCommands.getOrDefault(command, null);

    if (c == null) {
      this.view.renderMessage("Invalid Command. Try Again.");
    } else {
      c.runCommand();
    }
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();
    if (command.equals("Image Selection")) {
      JComboBox<String> imageSelectionBox = (JComboBox<String>) e.getSource();
      ImageProcessingGUIViewActions c = new ImageSelectionAction(this.model, this.view,
              imageSelectionBox);
      c.runCommand();
      view.refresh();
    } else {
      this.runCommand(command);
      view.refresh();
    }
  }
}
