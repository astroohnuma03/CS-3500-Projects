package main;

import controller.ImageProcessingController;
import controller.ImageProcessingControllerImpl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import controller.ImageProcessingGUIControllerImpl;
import model.ImageProcessingModel;
import model.ImageProcessingModelImpl;
import view.ImageProcessingGUIViewImpl;
import view.ImageProcessingView;
import view.ImageProcessingViewImpl;

/**
 * Class which represents a program that allows a user to process images in various ways.
 */
public final class ImageProcessor {

  /**
   * Runs the image processor by allowing user to input text commands.
   *
   * @param args Arguments for running the method
   */

  public static void main(String[] args) {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, System.out);
    ImageProcessingController controller;

    if (args.length > 0 && args[0].equalsIgnoreCase("-file")) {
      // Use a script to operate program
      try {
        controller = new ImageProcessingControllerImpl(model, view,
                new InputStreamReader(new FileInputStream(args[1])));
      } catch (FileNotFoundException e) {
        throw new RuntimeException(e);
      }
    } else if (args.length > 0 && args[0].equalsIgnoreCase("-text")) {
      // Use terminal prompts to operate program
      controller = new ImageProcessingControllerImpl(model, view, new InputStreamReader(System.in));
    } else if (args.length > 0) {
      // Argument provided, but not -file or -text, sends message and quits
      try {
        view.renderMessage("Invalid arguments");
        return;
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    } else {
      // Default, runs program with GUI if no arguments are provided
      controller = new ImageProcessingGUIControllerImpl(model,
              new ImageProcessingGUIViewImpl(model));
    }
    controller.runProgram();
  }
}
