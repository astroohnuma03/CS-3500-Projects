package model;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class represents an image.
 */
public class Image {
  private int width;
  private int height;
  private int maxValue;
  private Pixel[][] imageBody;

  /**
   * This is the default constructor which takes in a given width, height, maxValue, and imageBody.
   *
   * @param width     The width of the image
   * @param height    The height of the image
   * @param maxValue  The max value for a rgb component of the entire image
   * @param imageBody An array of pixels which represent the actual image
   */
  public Image(int width, int height, int maxValue, Pixel[][] imageBody) {
    if (width <= 0 || height <= 0) {
      throw new IllegalArgumentException("Width or height values cannot be zero or lower");
    }

    if (maxValue < 0 || maxValue > 255) {
      throw new IllegalArgumentException("Invalid max value");
    }

    if (imageBody == null) {
      throw new IllegalArgumentException("Body of image cannot be empty");
    }

    this.width = width;
    this.height = height;
    this.maxValue = maxValue;
    this.imageBody = imageBody;
  }

  /**
   * Creates an integer, integer hashmap with 256 entries with keys from 0 to 255.
   *
   * @return The integer, integer hashmap
   */
  private Map<Integer, Integer> create256EntryMap() {
    Map<Integer, Integer> map = new HashMap<Integer, Integer>();
    for (int i = 0; i < 256; i++) {
      map.put(i, 0);
    }
    return map;
  }

  /**
   * Creates a list of three hashsets which represent the count of each value for red, green, and
   * blue components for all the pixels in this image as well as an intensity map.
   *
   * @return A list of hashsets
   */
  public List<Map<Integer, Integer>> createRGBList() {
    List<Map<Integer, Integer>> rgbMapList = new ArrayList<Map<Integer, Integer>>();
    Map<Integer, Integer> redPixelMap = this.create256EntryMap();
    Map<Integer, Integer> greenPixelMap = this.create256EntryMap();
    Map<Integer, Integer> bluePixelMap = this.create256EntryMap();
    Map<Integer, Integer> intensityPixelMap = this.create256EntryMap();

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int rValue = this.imageBody[i][j].getRComponent();
        int gValue = this.imageBody[i][j].getGComponent();
        int bValue = this.imageBody[i][j].getBComponent();
        int intensityValue = (rValue + gValue + bValue) / 3;
        if (redPixelMap.containsKey(rValue)) {
          redPixelMap.replace(rValue, redPixelMap.get(rValue) + 1);
        }
        if (greenPixelMap.containsKey(gValue)) {
          greenPixelMap.replace(gValue, greenPixelMap.get(gValue) + 1);
        }
        if (bluePixelMap.containsKey(bValue)) {
          bluePixelMap.replace(bValue, bluePixelMap.get(bValue) + 1);
        }
        if (intensityPixelMap.containsKey(intensityValue)) {
          intensityPixelMap.replace(intensityValue, intensityPixelMap.get(intensityValue) + 1);
        }
      }
    }
    rgbMapList.add(redPixelMap);
    rgbMapList.add(greenPixelMap);
    rgbMapList.add(bluePixelMap);
    rgbMapList.add(intensityPixelMap);
    return rgbMapList;
  }

  /**
   * Creates a grayscale version of this image using the given color as a guide.
   *
   * @param color The color to use to visualize the grayscale image
   * @return A new image which is a grayscale version of this image
   */
  public Image grayscaleImage(String color) {
    switch (color) {
      case "red":
        Pixel[][] retR = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retR[i][j] = this.imageBody[i][j].createGrayScalePixel("red");
          }
        }
        return new Image(this.width, this.height, this.maxValue, retR);
      case "green":
        Pixel[][] retG = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retG[i][j] = this.imageBody[i][j].createGrayScalePixel("green");
          }
        }
        return new Image(this.width, this.height, this.maxValue, retG);
      case "blue":
        Pixel[][] retB = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retB[i][j] = this.imageBody[i][j].createGrayScalePixel("blue");
          }
        }
        return new Image(this.width, this.height, this.maxValue, retB);
      default:
        throw new IllegalArgumentException("Invalid color");
    }
  }

  /**
   * Creates a new version of this image using either the value, intensity, or luma interpretations
   * of brightness.
   *
   * @param vil Use either value, intensity, or luma to interpret brightness for the image
   * @return a new version of this image using either the value, intensity, or luma interpretations
   *         of brightness.
   */
  public Image vilImage(String vil) {
    switch (vil) {
      case "value":
        Pixel[][] retV = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retV[i][j] = this.imageBody[i][j].createValuePixel();
          }
        }
        return new Image(this.width, this.height, this.maxValue, retV);
      case "intensity":
        Pixel[][] retA = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retA[i][j] = this.imageBody[i][j].createAveragePixel();
          }
        }
        return new Image(this.width, this.height, this.maxValue, retA);
      case "luma":
        Pixel[][] retL = new Pixel[this.height][this.width];
        for (int i = 0; i < height; i++) {
          for (int j = 0; j < width; j++) {
            retL[i][j] = this.imageBody[i][j].createLumaPixel();
          }
        }
        return new Image(this.width, this.height, this.maxValue, retL);
      default:
        throw new IllegalArgumentException("Invalid input");
    }
  }

  /**
   * Creates a new version of this image with the rgb value of every pixel increased or decreased
   * by the incr based on whether it is positive or negative.
   *
   * @param incr The amount to incr every rgb value of every pixel
   * @return a new version of this image with the rgb value of every pixel increased or decreased
   *         the incr based on whether it is positive or negative.
   */
  public Image brightnessImage(int incr) {
    Pixel[][] ret = new Pixel[this.height][this.width];
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        ret[i][j] = this.imageBody[i][j].createBrightnessPixel(incr);
      }
    }
    return new Image(this.width, this.height, this.maxValue, ret);
  }

  /**
   * Creates a string representing this image, which can be used as a PPM file. Lists the width,
   * height, and max color value followed by the RGB values of each pixel.
   *
   * @return A string of this image which can be used as a PPM file.
   */
  public String toString() {
    // Creates header of the image
    StringBuilder ret = new StringBuilder().append("P3\n# Created by A + T\n"
        + this.width + "\n" + this.height + "\n" + this.maxValue + "\n");

    // Goes through each pixel and adds RGB values to string
    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        ret.append(this.imageBody[row][col].toString() + "\n");
      }
    }

    return ret.toString();
  }

  /**
   * Creates a new image whose pixels are flipped either vertically or horizontally.
   *
   * @param verticalHorizontal Direction of the flip, vertical or horizontal
   * @return Flipped image
   */
  public Image flipImage(String verticalHorizontal) {
    switch (verticalHorizontal) {
      case "vertical":
        return new Image(this.width, this.height, this.maxValue, this.flipVertical());
      case "horizontal":
        return new Image(this.width, this.height, this.maxValue, this.flipHorizontal());
      default:
        throw new IllegalArgumentException("Invalid direction.");
    }
  }

  /**
   * Creates a new ImageBody flipped horizontally.
   *
   * @return New version of this Image's ImageBody flipped horizontally
   */
  private Pixel[][] flipHorizontal() {
    Pixel[][] ret = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        ret[row][col] = this.imageBody[row][this.width - col - 1];
      }
    }

    return ret;
  }

  /**
   * Creates a new ImageBody flipped vertically.
   *
   * @return New version of this Image's ImageBody flipped vertically
   */
  private Pixel[][] flipVertical() {
    Pixel[][] ret = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        ret[row][col] = this.imageBody[this.height - row - 1][col];
      }
    }

    return ret;
  }

  /**
   * Custom equals function.
   *
   * @param other The other instance to compare to.
   * @return returns true if this and other are equal, false otherwise
   */
  @Override
  public boolean equals(Object other) {
    if (this == other) {
      return true;
    }

    if (!(other instanceof Image)) {
      return false;
    }

    Image o = (Image) other;
    return this.width == o.width && this.height == o.height && this.maxValue == o.maxValue &&
        Arrays.deepEquals(this.imageBody, o.imageBody);
  }

  /**
   * Custom hashCode function.
   *
   * @return A hashcode value
   */
  @Override
  public int hashCode() {
    return this.width + this.height * 1000;
  }

  /**
   * Creates a new image whose pixels are blurred.
   *
   * @return Blurred image
   */
  public Image blurImage() {
    Pixel[][] blurred = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        double[][] kernel = new double[][]{new double[]{0.0625, 0.125, 0.0625},
            new double[]{0.125, 0.25, 0.125},
            new double[]{0.0625, 0.125, 0.0625}};
        blurred[row][col] = applyKernel(row, col, kernel);
      }
    }

    return new Image(this.width, this.height, this.maxValue, blurred);
  }

  /**
   * Creates a new image whose pixels are sharpened.
   *
   * @return Sharpened image
   */
  public Image sharpenImage() {
    Pixel[][] sharpened = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        double[][] kernel = new double[][]{new double[]{-0.125, -0.125, -0.125, -0.125, -0.125},
            new double[]{-0.125, 0.25, 0.25, 0.25, -0.125},
            new double[]{-0.125, 0.25, 1, 0.25, -0.125},
            new double[]{-0.125, 0.25, 0.25, 0.25, -0.125},
            new double[]{-0.125, -0.125, -0.125, -0.125, -0.125}};

        sharpened[row][col] = applyKernel(row, col, kernel);
      }
    }

    return new Image(this.width, this.height, this.maxValue, sharpened);
  }

  /**
   * Applies a kernel to a pixel in this image, kernel is represented as a matrix of doubles.
   *
   * @param row    The row of the pixel
   * @param col    The column of the pixel
   * @param kernel The kernel, represented as a matrix of doubles
   * @return Pixel of the kernel's creation
   */
  private Pixel applyKernel(int row, int col, double[][] kernel) {
    int red = 0;
    int green = 0;
    int blue = 0;

    for (int kernRow = 0; kernRow < kernel.length; kernRow++) {
      for (int kernCol = 0; kernCol < kernel.length; kernCol++) {
        // Where in the imageBody the pixel being inspected is
        int bodyRow = row - kernel.length / 2 + kernRow;
        int bodyCol = col - kernel.length / 2 + kernCol;

        if (bodyRow >= 0 && bodyRow < this.height && bodyCol >= 0 && bodyCol < this.width) {
          red = red + this.imageBody[bodyRow][bodyCol]
              .applyCompDouble("red", kernel[kernRow][kernCol]);
          green = green + this.imageBody[bodyRow][bodyCol]
              .applyCompDouble("green", kernel[kernRow][kernCol]);
          blue = blue + this.imageBody[bodyRow][bodyCol]
              .applyCompDouble("blue", kernel[kernRow][kernCol]);
        }

      }
    }

    return new Pixel(NumUtil.inBounds(red, 0, this.maxValue),
        NumUtil.inBounds(green, 0, this.maxValue),
        NumUtil.inBounds(blue, 0, this.maxValue));
  }

  /**
   * Creates a grayscale of this image using color transformations.
   *
   * @return Grayscaled version of this image
   */
  public Image transformGrayScale() {
    Pixel[][] grayscaled = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        double[][] kernel = new double[][]{new double[]{0.2126, 0.7152, 0.0722},
            new double[]{0.2126, 0.7152, 0.0722}, new double[]{0.2126, 0.7152, 0.0722}};

        grayscaled[row][col] = applyColorTrans(this.imageBody[row][col], kernel);
      }
    }

    return new Image(this.width, this.height, this.maxValue, grayscaled);
  }

  /**
   * Creates a new image by applying a sepia color transformation to this image.
   *
   * @return Sepia version of this image
   */
  public Image sepiaImage() {
    Pixel[][] sepiaed = new Pixel[this.height][this.width];

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        double[][] kernel = new double[][]{new double[]{0.393, 0.769, 0.189},
            new double[]{0.349, 0.686, 0.168},
            new double[]{0.272, 0.534, 0.131}};

        sepiaed[row][col] = applyColorTrans(this.imageBody[row][col], kernel);
      }
    }

    return new Image(this.width, this.height, this.maxValue, sepiaed);
  }

  /**
   * Applies a color transformation to an individual pixel.
   *
   * @param pixel  The pixel to be transformed
   * @param kernel The kernel to apply transformation
   * @return The transformed pixel
   */
  private Pixel applyColorTrans(Pixel pixel, double[][] kernel) {
    if (kernel.length != 3 || kernel[0].length != 3
        || kernel[1].length != 3 || kernel[2].length != 3) {
      throw new IllegalArgumentException("Color Transformation kernels must be 3x3");
    }

    int[] components = new int[3];

    for (int kernRow = 0; kernRow < 3; kernRow++) {
      components[kernRow] = pixel.applyCompDouble("red", kernel[kernRow][0])
          + pixel.applyCompDouble("green", kernel[kernRow][1])
          + pixel.applyCompDouble("blue", kernel[kernRow][2]);
    }

    return new Pixel(NumUtil.inBounds(components[0], 0, this.maxValue),
        NumUtil.inBounds(components[1], 0, this.maxValue),
        NumUtil.inBounds(components[2], 0, this.maxValue));
  }

  /**
   * Creates a BufferedImage out of this image.
   *
   * @return This image as a buffered image
   */
  public BufferedImage toBufferedImage() {
    BufferedImage buf = new BufferedImage(this.width, this.height, BufferedImage.TYPE_INT_RGB);

    for (int row = 0; row < this.height; row++) {
      for (int col = 0; col < this.width; col++) {
        buf.setRGB(col, row, this.imageBody[row][col].asColor().getRGB());
      }
    }

    return buf;
  }
}
