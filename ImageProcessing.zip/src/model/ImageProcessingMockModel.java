package model;

import java.util.ArrayList;
import java.util.List;

/**
 * A mock version of the image processing model for use in testing the outputs of methods for the
 * controller.
 */
public class ImageProcessingMockModel implements ImageProcessingModel {
  private final StringBuilder log;

  /**
   * Default constructor for the mock model which takes in a StringBuilder log to keep track of
   * inputs.
   *
   * @param log The StringBuilder to keep track of model inputs
   */
  public ImageProcessingMockModel(StringBuilder log) {
    if (log == null) {
      throw new IllegalArgumentException("log cannot be null");
    }
    this.log = log;
  }

  @Override
  public Image findImage(String imageName) {
    this.log.append("(find) imageName: " + imageName + "\n");
    return null;
  }

  @Override
  public boolean hasImage(String imageName) {
    this.log.append("(has) imageName: " + imageName + "\n");
    return false;
  }

  @Override
  public void replaceImage(String oldImage, Image newImage) {
    this.log.append("(replace) oldImage: " + oldImage + ", newImage: " + newImage + "\n");
  }

  @Override
  public void removeImage(String image) {
    this.log.append("(remove) image: " + image + "\n");
  }

  @Override
  public List<String> getImageList() {
    List<String> empty = new ArrayList<String>();
    return empty;
  }

  @Override
  public void loadImage(String fileName, String imageName) {
    this.log.append("(load) fileName: " + fileName + ", imageName: " + imageName + "\n");
  }

  @Override
  public void createGrayscale(String color, String imageName, String newImageName) {
    this.log.append("(grayscale) color: " + color + ", imageName: " + imageName + "," +
            " newImageName: " + newImageName + "\n");
  }

  @Override
  public void createVILImage(String vil, String imageName, String newImageName) {
    this.log.append("(vil) vil: " + vil + ", imageName: " + imageName + "," +
            " newImageName: " + newImageName + "\n");
  }

  @Override
  public void createFlippedImage(String verticalHorizontal, String imageName, String newImageName) {
    this.log.append("(flipped) vertHorz: " + verticalHorizontal + ", imageName: " + imageName + ","
            + " newImageName: " + newImageName + "\n");
  }

  @Override
  public void createBrightnessImage(int increment, String imageName, String newImageName) {
    this.log.append("(brightness) incr: " + increment + ", imageName: " + imageName + "," +
            " newImageName: " + newImageName + "\n");
  }

  @Override
  public void blur(String imageName, String newImageName) throws IllegalArgumentException {
    this.log.append("(blur) imageName: " + imageName + ", newImageName: " + newImageName + "\n");
  }

  @Override
  public void sharpen(String imageName, String newImageName) throws IllegalArgumentException {
    this.log.append("(sharpen) imageName: " + imageName + ", newImageName: " + newImageName + "\n");
  }

  @Override
  public void createSepiaImage(String imageName, String newImageName)
          throws IllegalArgumentException {
    this.log.append("(sepia) imageName: " + imageName + ", newImageName: " + newImageName + "\n");
  }

  @Override
  public void createTransformGrayscale(String imageName, String newImageName)
          throws IllegalArgumentException {
    this.log.append("(transform grayscale) imageName: " + imageName + ", newImageName: "
            + newImageName + "\n");
  }
}
