package model;

import java.util.List;

/**
 * This interface represents the operations offered by the image processing model. One object of
 * this model is the image data for one ppm image.
 */
public interface ImageProcessingModel {

  /**
   * Returns an image from the models image map based on the given imageName.
   *
   * @param imageName The name of the image to return
   * @return An image with the given name in the image map
   */
  Image findImage(String imageName);

  /**
   * Checks if an image with the given imageName exists in this models image map.
   *
   * @param imageName The name of the image to search for
   * @return true if the image does exist in this models image map, false otherwise.
   */
  boolean hasImage(String imageName);

  /**
   * Load an image from the given fileName and path and refer to it by the given imageName.
   *
   * @param fileName  The name of the file to be loaded
   * @param imageName The name this program will use to refer to this file
   */
  void loadImage(String fileName, String imageName);

  /**
   * Create a grayscale version of the image with the given imageName and using the given color
   * (either red, green, or blue) to visualize the new grayscale image.
   *
   * @param color        The color used to visualize the new grayscale image (either red, green, or
   *                     blue)
   * @param imageName    The name of the image to create a grayscale version of
   * @param newImageName The new name given to the grayscale version of the given image
   */
  void createGrayscale(String color, String imageName, String newImageName);

  /**
   * Create a new version of the image with the given imageName based on either value, intensity,
   * and luma.
   *
   * @param vil          The factor used to visualize a new image (either based on value,
   *                     intensity, or luma)
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the altered version of the given image
   */
  void createVILImage(String vil, String imageName, String newImageName);

  /**
   * Create a new version of the image with the given imageName flipped either horizontally or
   * vertically.
   *
   * @param verticalHorizontal The direction to flip the image in (either vertical or horizontal)
   * @param imageName          The name of the image to create a new version of
   * @param newImageName       The new name given to the flipped version of the given image
   */
  void createFlippedImage(String verticalHorizontal, String imageName, String newImageName);

  /**
   * Create a new version of the image with the given imageName which is either brightened or
   * darkened by the given increment (positive for brightening, negative for darkening).
   *
   * @param increment    The amount to increment the brightness of the new image (positive for
   *                     brightening, negative for darkening)
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the altered version of the given image
   */
  void createBrightnessImage(int increment, String imageName, String newImageName);

  /**
   * Creates a String which lists the images in this model.
   *
   * @return List of images
   */
  String toString();

  /**
   * Creates a new version of the image with the given imageName which is blurred.
   *
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the blurred image
   * @throws IllegalArgumentException Invalid image
   */
  void blur(String imageName, String newImageName) throws IllegalArgumentException;

  /**
   * Creates a new version of the image with the given imageName which is sharpened.
   *
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the sharpened image
   * @throws IllegalArgumentException Invalid image
   */
  void sharpen(String imageName, String newImageName) throws IllegalArgumentException;

  /**
   * Creates a new sepia version of the image with the given imageName.
   *
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the sepia image
   * @throws IllegalArgumentException Invalid image
   */
  void createSepiaImage(String imageName, String newImageName) throws IllegalArgumentException;

  /**
   * Creates a new grayscale version of the image with the given imageName.
   *
   * @param imageName    The name of the image to create a new version of
   * @param newImageName The new name given to the grayscale image
   * @throws IllegalArgumentException Invalid image
   */
  void createTransformGrayscale(String imageName, String newImageName)
          throws IllegalArgumentException;

  /**
   * Replaces an image in the hashmap for this model with the given image.
   * @param oldImage The name of the image to be replaced
   * @param newImage The image to replace the old one
   */
  void replaceImage(String oldImage, Image newImage);

  /**
   * Removes the given image from this model's hashmap.
   * @param image The image to be removed
   */
  void removeImage(String image);

  /**
   * Returns the keys for the image map of this model as an array of strings.
   * @return The keys of the image map in an array
   */
  List<String> getImageList();
}
