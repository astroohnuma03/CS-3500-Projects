package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Class which represents a place to load and save multiple images and perform implemented
 * operations to create new images.
 */
public class ImageProcessingModelImpl implements ImageProcessingModel {
  private Map<String, Image> imageMap;

  /**
   * Default constructor which takes in no arguments and initializes an empty hashmap for the
   * images.
   */
  public ImageProcessingModelImpl() {
    this.imageMap = new LinkedHashMap<String, Image>();
  }

  @Override
  public Image findImage(String imageName) {
    return this.imageMap.get(imageName);
  }

  @Override
  public boolean hasImage(String imageName) {
    return this.imageMap.containsKey(imageName);
  }

  @Override
  public void replaceImage(String oldImage, Image newImage) {
    this.imageMap.replace(oldImage, newImage);
  }

  @Override
  public void removeImage(String image) {
    this.imageMap.remove(image);
  }

  @Override
  public List<String> getImageList() {
    ArrayList<String> ret = new ArrayList<>(this.imageMap.keySet());
    return ret;
  }

  @Override
  public void loadImage(String fileName, String imageName) throws IllegalArgumentException {
    if (fileName == null || imageName == null) {
      throw new IllegalArgumentException("fileName or imageName cannot be null");
    }

    Image img;
    String extension = fileName.substring(fileName.indexOf(".") + 1);

    // If the image is a ppm uses old ImageUtil, otherwise uses ImageIO
    if (extension.equalsIgnoreCase("ppm")) {
      img = ImageUtil.createImage(fileName);
    } else {
      try {
        img = ImageUtil.createIOImage(fileName);
      } catch (IOException e) {
        throw new IllegalArgumentException(e);
      }
    }

    imageMap.put(imageName, img);
  }

  @Override
  public void createGrayscale(String color, String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image grayImg = imageMap.get(imageName).grayscaleImage(color);
    imageMap.put(newImageName, grayImg);
  }

  @Override
  public void createVILImage(String vil, String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image vilImg = imageMap.get(imageName).vilImage(vil);
    imageMap.put(newImageName, vilImg);
  }

  @Override
  public void createFlippedImage(String verticalHorizontal, String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image flippedImg = this.imageMap.get(imageName).flipImage(verticalHorizontal);
    this.imageMap.put(newImageName, flippedImg);
  }

  @Override
  public void createBrightnessImage(int increment, String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image brightnessImg = this.imageMap.get(imageName).brightnessImage(increment);
    this.imageMap.put(newImageName, brightnessImg);
  }

  @Override
  public String toString() {
    List<String> keys = this.getImageList();

    StringBuilder ret = new StringBuilder().append("Images: ");

    for (int image = 0; image < keys.size(); image++) {
      ret.append(keys.get(image));

      if (image != keys.size() - 1) {
        ret.append(", ");
      }
    }

    return ret.toString();
  }

  @Override
  public void blur(String imageName, String newImageName) throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image blurImage = this.imageMap.get(imageName).blurImage();
    this.imageMap.put(newImageName, blurImage);
  }

  @Override
  public void sharpen(String imageName, String newImageName) throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image sharpenImage = this.imageMap.get(imageName).sharpenImage();
    this.imageMap.put(newImageName, sharpenImage);
  }

  @Override
  public void createSepiaImage(String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image sepiaImage = this.imageMap.get(imageName).sepiaImage();
    this.imageMap.put(newImageName, sepiaImage);
  }

  @Override
  public void createTransformGrayscale(String imageName, String newImageName)
          throws IllegalArgumentException {
    if (this.imageMap.get(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image grayscaleImage = this.imageMap.get(imageName).transformGrayScale();
    this.imageMap.put(newImageName, grayscaleImage);
  }

}
