package model;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;

import javax.imageio.ImageIO;


/**
 * This class contains utility methods to read a PPM image from file and simply print its contents.
 * Feel free to change this method as required.
 */
public class ImageUtil {

  /**
   * Read an image file in the PPM format and print the colors.
   *
   * @param filename the path of the file.
   */
  public static void readPPM(String filename) {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(filename));
    } catch (FileNotFoundException e) {
      System.out.println("File " + filename + " not found!");
      return;
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = sc.nextInt();
    System.out.println("Width of image: " + width);
    int height = sc.nextInt();
    System.out.println("Height of image: " + height);
    int maxValue = sc.nextInt();
    System.out.println("Maximum value of a color in this file (usually 255): " + maxValue);

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("Color of pixel (" + j + "," + i + "): " + r + "," + g + "," + b);
      }
    }
  }

  /**
   * Creates an image object based off of an image file with the given filename that is not a ppm
   * (e.g. png, jpg, bpm).
   *
   * @param filename The name of the image file to use
   * @return An image object based off of the given image file
   * @throws IOException When there is an IO error
   */
  public static Image createIOImage(String filename) throws IOException {
    File file = new File(filename);

    BufferedImage bufImg = ImageIO.read(file);
    Pixel[][] pixels = new Pixel[bufImg.getHeight()][bufImg.getWidth()];

    for (int height = 0; height < bufImg.getHeight(); height++) {
      for (int width = 0; width < bufImg.getWidth(); width++) {
        Color clr = new Color(bufImg.getRGB(width, height));

        int r = clr.getRed();
        int g = clr.getGreen();
        int b = clr.getBlue();

        pixels[height][width] = new Pixel(r, g, b);
      }
    }

    return new Image(bufImg.getWidth(), bufImg.getHeight(), 255, pixels);
  }

  /**
   * Creates an image object based off of an image file with the given filename.
   *
   * @param filename The filename of the image to create an image object of
   * @return an image object
   */
  public static Image createImage(String filename) {
    Scanner scanner;

    try {
      scanner = new Scanner(new FileInputStream(filename));
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("File not found");
    }

    StringBuilder imageBuilder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (scanner.hasNextLine()) {
      String s = scanner.nextLine();
      if (s.charAt(0) != '#') {
        imageBuilder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    scanner = new Scanner(imageBuilder.toString());

    String token;

    token = scanner.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = scanner.nextInt();
    int height = scanner.nextInt();
    int maxValue = scanner.nextInt();

    Pixel[][] imageBody = new Pixel[height][width];
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = scanner.nextInt();
        int g = scanner.nextInt();
        int b = scanner.nextInt();
        imageBody[i][j] = new Pixel(r, g, b);
      }
    }

    return new Image(width, height, maxValue, imageBody);
  }

  /**
   * Demo main method to show how the read file method should work.
   *
   * @param args The inputs to use for the main method
   */
  public static void main(String[] args) {
    String filename;

    if (args.length > 0) {
      filename = args[0];
    } else {
      filename = "Images/Koala.ppm";
    }

    ImageUtil.readPPM(filename);
  }
}

