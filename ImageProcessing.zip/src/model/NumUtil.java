package model;

/**
 * Utility class which provides methods that ensure numbers for pixel calculations are correct.
 */
public class NumUtil {

  /**
   * Changes a number if necessary to keep in the given bounds.
   *
   * @param num The number being kept in bounds
   * @param min The lower bound
   * @param max The upper bound
   * @return A number compliant with the bounds
   */
  public static int inBounds(int num, int min, int max) {
    return Math.min(Math.max(num, min), max);
  }
}
