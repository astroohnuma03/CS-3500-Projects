package model;

import java.awt.Color;

/**
 * This class represents a single pixel in an image.
 */
public class Pixel {
  private int red;
  private int green;
  private int blue;

  /**
   * The default constructor for a pixel which takes in a value for red, green, and blue.
   *
   * @param red   The red value
   * @param green The green value
   * @param blue  The blue value
   */
  public Pixel(int red, int green, int blue) {
    if (red < 0 || red > 255 || green < 0 || green > 255 || blue < 0 || blue > 255) {
      throw new IllegalArgumentException("Invalid RGB values");
    }

    this.red = red;
    this.green = green;
    this.blue = blue;
  }

  /**
   * Creates a new pixel where the red, green, and blue values are the highest rgb value for this
   * pixel.
   *
   * @return A new pixel where each value is the highest rgb value of this pixel
   */
  public Pixel createValuePixel() {
    if (this.red > this.green && this.red > this.blue) {
      return new Pixel(this.red, this.red, this.red);
    } else if (this.green > this.red && this.green > this.blue) {
      return new Pixel(this.green, this.green, this.green);
    } else {
      return new Pixel(this.blue, this.blue, this.blue);
    }
  }

  /**
   * Creates a new pixel where the red, green, and blue values are the average of the rgb values
   * for this pixel.
   *
   * @return Returns a new pixel where the red, green, and blue values are the average of the rgb
   *         values for this pixel
   */
  public Pixel createAveragePixel() {
    int average = (this.red + this.green + this.blue) / 3;
    return new Pixel(average, average, average);
  }

  /**
   * Creates a new pixel where the red, green, and blue values are the weighted sum of the rgb
   * values for this pixel according to this equation: 0.2126r + 0.7152g + 0.0722b
   *
   * @return returns a new pixel where the red, green, and blue values are the weighted sum of the
   *         rgb values for this pixel according to this equation: 0.2126r + 0.7152g + 0.0722b
   */
  public Pixel createLumaPixel() {
    int weightedSum = (int) Math.round((this.red * 0.2126) + (this.green * 0.7152) +
            (this.blue * 0.0722));

    return new Pixel(weightedSum, weightedSum, weightedSum);
  }

  /**
   * Creates a new pixel where the red, green, and blue values are set to be the rgb value of the
   * given color for this pixel.
   *
   * @param color The color to set every rgb value to
   * @return a new pixel where the red, green, and blue values are set to be the rgb value of the
   *         given color for this pixel.
   */
  public Pixel createGrayScalePixel(String color) {
    switch (color) {
      case "red":
        return new Pixel(this.red, this.red, this.red);
      case "green":
        return new Pixel(this.green, this.green, this.green);
      case "blue":
        return new Pixel(this.blue, this.blue, this.blue);
      default:
        throw new IllegalArgumentException("Invalid color");
    }
  }

  /**
   * Creates a pixel where each rgb value is incremented by the given integer which represents
   * brightening if it is positive and darkening if it is negative.
   *
   * @param incr The amount to increment the rgb values
   * @return a pixel where each rgb value is incremented by the given integer which represents
   *         brightening if it is positive and darkening if it is negative.
   */
  public Pixel createBrightnessPixel(int incr) {
    return new Pixel(NumUtil.inBounds(this.red + incr, 0, 255),
            NumUtil.inBounds(this.green + incr, 0, 255),
            NumUtil.inBounds(this.blue + incr, 0, 255));
  }

  public String toString() {
    return this.red + " " + this.green + " " + this.blue;
  }

  /**
   * Custom equals function.
   *
   * @param other The other object to compare to
   * @return True if this and the other object are the same
   */
  @Override
  public boolean equals(Object other) {
    if (this == other) {
      return true;
    }

    if (!(other instanceof Pixel)) {
      return false;
    }

    Pixel o = (Pixel) other;
    return this.red == o.red && this.green == o.green && this.blue == o.blue;
  }

  /**
   * Custom hashCode function.
   *
   * @return A hashCode value
   */
  @Override
  public int hashCode() {
    return this.red + this.blue + this.green * 100;
  }

  /**
   * Multiplies a component of this pixel by a given double.
   *
   * @param color red/green/blue
   * @param d     A double to multiply the color value by
   * @return Resulting int representing the component after being multiplied
   *         by the double.
   */
  public int applyCompDouble(String color, double d) {
    switch (color) {
      case "red":
        return (int) Math.round(this.red * d);
      case "green":
        return (int) Math.round(this.green * d);
      case "blue":
        return (int) Math.round(this.blue * d);
      default:
        throw new IllegalArgumentException("Invalid color");
    }
  }

  /**
   * Returns a color representing this pixel.
   *
   * @return This pixel's color
   */
  public Color asColor() {
    return new Color(this.red, this.green, this.blue);
  }

  /**
   * Returns the red component of this pixel.
   *
   * @return The red component
   */
  public int getRComponent() {
    int r = this.red;
    return r;
  }

  /**
   * Returns the green component of this pixel.
   *
   * @return The green component
   */
  public int getGComponent() {
    int g = this.green;
    return g;
  }

  /**
   * Returns the blue component of this pixel.
   *
   * @return The blue component
   */
  public int getBComponent() {
    int b = this.blue;
    return b;
  }
}
