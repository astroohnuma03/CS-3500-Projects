package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the blur function.
 */
public class Blur implements ImageProcessingCommand {
  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a new blurred version of an image.
   *
   * @param imageName    The name of the image being blurred
   * @param newImageName The name of the new blurred image being created
   */
  public Blur(String imageName, String newImageName) {
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.blur(this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by blurring " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
