package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the create brightness image function.
 */
public class CreateBrightnessImage implements ImageProcessingCommand {

  private int increment;
  private String imageName;
  private String newImageName;

  /**
   * Constructor for changing the brightness of an image.
   *
   * @param increment    How much brightness should be modified by
   * @param imageName    The name of the image being modified
   * @param newImageName The name of the new brightened image being created
   */
  public CreateBrightnessImage(int increment, String imageName, String newImageName) {
    this.increment = increment;
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {

    try {
      try {
        model.createBrightnessImage(this.increment, this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by brightening " + this.imageName +
                " by " + this.increment);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
