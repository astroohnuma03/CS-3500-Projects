package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the create flipped image function.
 */
public class CreateFlippedImage implements ImageProcessingCommand {
  private String verticalHorizontal;
  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a new version of the image with the given imageName flipped either
   * horizontally or vertically.
   *
   * @param verticalHorizontal Whether the flip is horizontal or vertical
   * @param imageName          The name of the image being flipped
   * @param newImageName       The name of the flipped image being created
   */
  public CreateFlippedImage(String verticalHorizontal, String imageName, String newImageName) {
    this.verticalHorizontal = verticalHorizontal;
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.createFlippedImage(this.verticalHorizontal, this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by " + this.verticalHorizontal +
                " flipping " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
