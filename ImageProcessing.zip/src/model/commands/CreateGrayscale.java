package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the create grayscale image function.
 */
public class CreateGrayscale implements ImageProcessingCommand {
  private String color;
  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a grayscale image from the given component from an already existing
   * image, and saving it as a new image.
   *
   * @param color        The color component (red, green, blue) being used for the grayscale
   * @param imageName    The image the grayscale is being made from
   * @param newImageName The name of the new grayscale image
   */
  public CreateGrayscale(String color, String imageName, String newImageName) {
    this.color = color;
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.createGrayscale(this.color, this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by " + this.color + " grayscaling " +
                this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
