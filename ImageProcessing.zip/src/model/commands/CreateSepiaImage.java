package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object representing the sepia image function.
 */
public class CreateSepiaImage implements ImageProcessingCommand {

  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a new sepia image.
   *
   * @param imageName    The image the sepia image is being created from
   * @param newImageName The name of the new sepia image
   */
  public CreateSepiaImage(String imageName, String newImageName) {
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.createSepiaImage(this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName
                + " by applying sepia to " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
