package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the function of grayscaling an image
 * using color transformations.
 */
public class CreateTransformGrayscale implements ImageProcessingCommand {

  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a grayscale using color transformations.
   *
   * @param imageName    The name of the image being grayscaled
   * @param newImageName The name of the new grayscaled image
   */
  public CreateTransformGrayscale(String imageName, String newImageName) {
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.createTransformGrayscale(this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by grayscaling " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
