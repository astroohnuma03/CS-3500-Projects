package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the create vil image function.
 */
public class CreateVILImage implements ImageProcessingCommand {
  private String vil;
  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a visualization of an image's brightness using value, intensity
   * or luma.
   *
   * @param vil          Use either value, average, or luma to interpret brightness for the image
   * @param imageName    The name of the image being visualized
   * @param newImageName The name of the image being created
   */
  public CreateVILImage(String vil, String imageName, String newImageName) {
    this.vil = vil;
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.createVILImage(this.vil, this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by Visualizing " + this.vil +
                " brightness on " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
