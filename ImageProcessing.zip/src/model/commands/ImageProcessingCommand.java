package model.commands;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Interface which represents all the commands possible for the image processing program.
 */
public interface ImageProcessingCommand {

  /**
   * Executes a set of operations on the model.
   *
   * @param model The model being operated on
   * @param view  The view which output is sent to
   */
  void runCommand(ImageProcessingModel model, ImageProcessingView view);
}
