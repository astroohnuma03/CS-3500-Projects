package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the list images method.
 */
public class ListImages implements ImageProcessingCommand {

  /**
   * Constructor for List command, only relies on model and view so doesn't take any parameters.
   */
  public ListImages() {
    // Doesn't take any parameters.
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      view.renderMessage(model.toString());
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
