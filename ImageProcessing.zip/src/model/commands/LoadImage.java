package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the load image method.
 */
public class LoadImage implements ImageProcessingCommand {
  private String fileName;
  private String imageName;

  /**
   * Constructor, takes the path of the file being loaded, and what name it should be saved as.
   *
   * @param fileName  The path of the file being loaded
   * @param imageName What the image should be saved as
   */
  public LoadImage(String fileName, String imageName) {
    this.fileName = fileName;
    this.imageName = imageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.loadImage(this.fileName, this.imageName);
        view.renderMessage("Loaded image " + this.imageName + " from " + this.fileName);
      } catch (IllegalArgumentException e) {
        view.renderMessage("File not found");
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
