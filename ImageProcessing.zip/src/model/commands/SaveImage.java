package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the save image method.
 */
public class SaveImage implements ImageProcessingCommand {
  private String fileWriter;
  private String imageName;

  /**
   * Save the image with the given name to the specified path which should include
   * the name of the file.
   *
   * @param fileWriter The path of where the image should be saved, including file name
   * @param imageName  The name of the image to be saved
   */
  public SaveImage(String fileWriter, String imageName) {
    this.fileWriter = fileWriter;
    this.imageName = imageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        view.saveImage(this.fileWriter, this.imageName);
        view.renderMessage("Saved image " + this.imageName + " at " + this.fileWriter);
      } catch (IllegalArgumentException e) {
        view.renderMessage("Image not found.");
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
