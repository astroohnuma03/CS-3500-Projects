package model.commands;

import java.io.IOException;

import model.ImageProcessingModel;
import view.ImageProcessingView;

/**
 * Function object which represents the sharpen image function.
 */
public class Sharpen implements ImageProcessingCommand {
  private String imageName;
  private String newImageName;

  /**
   * Constructor for creating a new sharpened version of an image.
   *
   * @param imageName    The name of the image being modified
   * @param newImageName The name of the new sharpened image being created
   */
  public Sharpen(String imageName, String newImageName) {
    this.imageName = imageName;
    this.newImageName = newImageName;
  }

  @Override
  public void runCommand(ImageProcessingModel model, ImageProcessingView view) {
    try {
      try {
        model.sharpen(this.imageName, this.newImageName);
        view.renderMessage("Created " + this.newImageName + " by sharpening " + this.imageName);
      } catch (IllegalArgumentException e) {
        view.renderMessage(e.toString());
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Appendable failed.");
    }
  }
}
