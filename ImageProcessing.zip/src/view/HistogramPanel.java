package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;

import model.Image;

/**
 * Custom JPanel class which represents a histogram of the rgb color values and intensity of an
 * image using a bar graph.
 */
public class HistogramPanel extends JPanel {
  private Image img;

  /**
   * Default constructor which takes in an image and creates a JPanel to represent a histogram
   * of the images rgb values and intensity.
   *
   * @param img The image to use
   */
  public HistogramPanel(Image img) {
    super();
    this.img = img;
    this.setBackground(Color.WHITE);
    this.setPreferredSize(new Dimension(600, 600));
  }

  /**
   * Updates the histogram to ensure it displays the data of the current image.
   *
   * @param newImg The current image being displayed
   */
  public void updateHist(Image newImg) {
    this.img = newImg;
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    // set up graph origin points and standard font
    int histogramOriginX = 40;
    int histogramOriginY = 560;
    Font normalFont = new Font(null, Font.PLAIN, 12);
    g.setFont(normalFont);

    // custom font which is used for the y-axis
    AffineTransform affineRotate = new AffineTransform();
    affineRotate.rotate(Math.toRadians(270), 0, 0);
    Font verticalFont = normalFont.deriveFont(affineRotate);

    // only run code if img isn't null to avoid null errors with create rgb list
    if (this.img != null) {
      // list which contains all the maps for the rgb values and intensity
      List<Map<Integer, Integer>> rgbValues = this.img.createRGBList();
      // map for red components of all pixels
      Map<Integer, Integer> redValues = rgbValues.get(0);
      // map for green components of all pixels
      Map<Integer, Integer> greenValues = rgbValues.get(1);
      // map for blue components of all pixels
      Map<Integer, Integer> blueValues = rgbValues.get(2);
      // map for intensity of all pixels
      Map<Integer, Integer> intensityValues = rgbValues.get(3);

      // draw the red component part of the histogram
      g.setColor(new Color(255, 0, 0, 80));
      for (int i = 0; i < 256; i++) {
        // Shorten frequency values to make histogram fit better on screen
        int rFreq = (int) Math.round(redValues.get(i) * 0.75);
        g.drawLine(histogramOriginX + i, histogramOriginY, histogramOriginX + i,
                histogramOriginY - rFreq);
      }

      // draw the green component part of the histogram
      g.setColor(new Color(0, 255, 0, 80));
      for (int i = 0; i < 256; i++) {
        // Shorten frequency values to make histogram fit better on screen
        int gFreq = (int) Math.round(greenValues.get(i) * 0.75);
        g.drawLine(histogramOriginX + i, histogramOriginY, histogramOriginX + i,
                histogramOriginY - gFreq);
      }

      // draw the blue component part of the histogram
      g.setColor(new Color(0, 0, 255, 80));
      for (int i = 0; i < 256; i++) {
        // Shorten frequency values to make histogram fit better on screen
        int bFreq = (int) Math.round(blueValues.get(i) * 0.75);
        g.drawLine(histogramOriginX + i, histogramOriginY, histogramOriginX + i,
                histogramOriginY - bFreq);
      }

      // draw the yellow component of the histogram
      g.setColor(new Color(255, 255, 0, 80));
      for (int i = 0; i < 256; i++) {
        // Shorten frequency values to make histogram fit better on screen
        int intensityFreq = (int) Math.round(intensityValues.get(i) * 0.75);
        g.drawLine(histogramOriginX + i, histogramOriginY, histogramOriginX + i,
                histogramOriginY - intensityFreq);
      }


      // draw the lines that border the histogram, the line bordering the y-axis has been adjusted
      // to match the shortened frequency values of all rgb components
      g.setColor(Color.BLACK);
      g.drawLine(histogramOriginX - 1, histogramOriginY + 1, histogramOriginX + 256,
              histogramOriginY + 1);
      g.drawLine(histogramOriginX - 1, histogramOriginY + 1, histogramOriginX - 1,
              histogramOriginY - 192);

      // draw the x-axis label
      g.drawString("0", histogramOriginX - 5, histogramOriginY + 15);
      g.drawString("255", histogramOriginX + 246, histogramOriginY + 15);
      g.drawString("RGB Values (0-255)", histogramOriginX + 70, histogramOriginY + 20);

      // draw the y-axis label with vertical font
      g.setFont(verticalFont);
      g.drawString("RGB Value Frequency", histogramOriginX - 10, histogramOriginY - 30);
      g.drawString("0", histogramOriginX - 10, histogramOriginY);
      g.drawString("255", histogramOriginX - 10, histogramOriginY - 182);
      g.setFont(normalFont);

      // draw the color key for the histogram
      g.drawString("Color Key:", histogramOriginX + 276, histogramOriginY - 100);
      g.setColor(Color.RED);
      g.drawString("Red = Red Component", histogramOriginX + 276, histogramOriginY - 80);
      g.setColor(Color.GREEN);
      g.drawString("Green = Green Component", histogramOriginX + 276,
              histogramOriginY - 60);
      g.setColor(Color.BLUE);
      g.drawString("Blue = Blue Component", histogramOriginX + 276,
              histogramOriginY - 40);
      g.setColor(Color.YELLOW);
      g.drawString("Yellow = Intensity", histogramOriginX + 276, histogramOriginY - 20);
    }
  }
}
