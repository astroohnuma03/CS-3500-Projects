package view;

import java.awt.event.ActionListener;

/**
 * Interface which represents an interactive graphical interface for the view, displaying images
 * to the user and various other information.
 */
public interface ImageProcessingGUIView extends ImageProcessingView {

  /**
   * Creates action listeners for the various buttons in the graphical interface.
   *
   * @param listener The listener to use
   */
  void setListener(ActionListener listener);

  /**
   * Renders a message in an easily viewable section of the GUI.
   *
   * @param message The message to be displayed
   */
  void renderMessage(String message);

  /**
   * Returns the name of the image currently being worked on in the graphical interface.
   *
   * @return The string representing the name of the image
   */
  String getCurrentImage();

  /**
   * Sets the current image being worked on in the graphical interface to the given image in the
   * model.
   *
   * @param imageName The new current image
   */
  void setCurrentImage(String imageName);

  /**
   * Sets this view to be visible.
   */
  void makeVisible();

  /**
   * Ensures that all graphics are updated correctly.
   */
  void refresh();

  /**
   * Simulates a user pressing the button identified by the given name.
   *
   * @param buttonName The button to simulate pressing
   */
  void simulateButtonActivation(String buttonName);
}
