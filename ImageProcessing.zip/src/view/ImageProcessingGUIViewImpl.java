package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.ImageProcessingModel;

/**
 * This class represents a graphical user interface for the image processing program and all the
 * ways a user can interact with it.
 */
public class ImageProcessingGUIViewImpl extends JFrame implements ImageProcessingGUIView {
  private final ImageProcessingModel model;
  private String currentImage;
  private List<String> images;
  private final JTextArea outputTextArea;
  private final JLabel imageLabel;
  private final HistogramPanel histogramPanel;

  private final JComboBox<String> imageSelectionBox;

  private final JButton loadImageButton;
  private final JButton saveImageButton;
  private final JButton grayscaleImageButton;
  private final JButton transformGrayscaleImageButton;
  private final JButton vilImageButton;
  private final JButton brightenImageButton;
  private final JButton flipImageButton;
  private final JButton blurImageButton;
  private final JButton sharpenImageButton;
  private final JButton sepiaImageButton;
  private final JButton listImagesButton;

  /**
   * Default constructor which takes in a model and creates a graphical interface.
   *
   * @param model The model to be used
   */
  public ImageProcessingGUIViewImpl(ImageProcessingModel model) {
    super();

    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }

    this.setTitle("Image Processing GUI");
    this.setSize(500, 500);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.model = model;

    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    JScrollPane mainScrollPane = new JScrollPane(mainPanel);
    add(mainScrollPane);

    JPanel imagePanel = new JPanel();
    imagePanel.setBorder(BorderFactory.createTitledBorder("Current Image:"));
    imagePanel.setLayout(new GridLayout(1, 0, 10, 10));
    mainPanel.add(imagePanel);

    imageLabel = new JLabel();
    JScrollPane imageScrollPane = new JScrollPane(imageLabel);
    if (this.currentImage == null) {
      imageLabel.setIcon(null);
    } else {
      model.Image modelImage = this.model.findImage(this.currentImage);
      Image img = modelImage.toBufferedImage();
      imageLabel.setIcon(new ImageIcon(img));
    }
    imageScrollPane.setPreferredSize(new Dimension(150, 150));
    imagePanel.add(imageScrollPane);

    histogramPanel = new HistogramPanel(this.model.findImage(this.currentImage));
    histogramPanel.setBorder(BorderFactory.createTitledBorder("Current Image's Histogram:"));
    JScrollPane histogramScrollPane = new JScrollPane(histogramPanel);
    mainPanel.add(histogramPanel);
    histogramPanel.add(histogramScrollPane);

    outputTextArea = new JTextArea(10, 20);
    JScrollPane outputTextScrollPane = new JScrollPane(outputTextArea);
    outputTextArea.setEditable(false);
    outputTextArea.setLineWrap(true);
    outputTextScrollPane.setBorder(BorderFactory.createTitledBorder("Image Processing Output:"));
    mainPanel.add(outputTextScrollPane);

    JPanel imageSelectionPanel = new JPanel();
    imageSelectionPanel.setBorder(BorderFactory.createTitledBorder("Image Selection:"));
    imageSelectionPanel.setLayout(new BoxLayout(imageSelectionPanel, BoxLayout.PAGE_AXIS));
    mainPanel.add(imageSelectionPanel);
    images = this.model.getImageList();
    imageSelectionBox = new JComboBox<String>();
    imageSelectionBox.setActionCommand("Image Selection");
    for (int i = 0; i < images.size(); i++) {
      imageSelectionBox.addItem(images.get(i));
    }
    imageSelectionPanel.add(imageSelectionBox);

    JPanel operationsPanel = new JPanel();
    operationsPanel.setBorder(BorderFactory.createTitledBorder("Image Processing Operations:"));
    operationsPanel.setLayout(new BoxLayout(operationsPanel, BoxLayout.PAGE_AXIS));
    mainPanel.add(operationsPanel);

    JPanel loadImagePanel = new JPanel();
    loadImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(loadImagePanel);
    loadImageButton = new JButton("Load an image file");
    loadImageButton.setActionCommand("Load");
    loadImagePanel.add(loadImageButton);

    JPanel saveImagePanel = new JPanel();
    saveImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(saveImagePanel);
    saveImageButton = new JButton("Save an image file");
    saveImageButton.setActionCommand("Save");
    saveImagePanel.add(saveImageButton);

    JPanel grayscaleImagePanel = new JPanel();
    grayscaleImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(grayscaleImagePanel);
    grayscaleImageButton = new JButton("Grayscale current image");
    grayscaleImageButton.setActionCommand("Grayscale");
    grayscaleImagePanel.add(grayscaleImageButton);

    JPanel transformGrayscaleImagePanel = new JPanel();
    grayscaleImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(transformGrayscaleImagePanel);
    transformGrayscaleImageButton = new JButton("Grayscale current image via color" +
            " transformation");
    transformGrayscaleImageButton.setActionCommand("Transform Grayscale");
    transformGrayscaleImagePanel.add(transformGrayscaleImageButton);

    JPanel vilImagePanel = new JPanel();
    vilImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(vilImagePanel);
    vilImageButton = new JButton("Visualize current image");
    vilImageButton.setActionCommand("VIL");
    vilImagePanel.add(vilImageButton);

    JPanel flipImagePanel = new JPanel();
    flipImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(flipImagePanel);
    flipImageButton = new JButton("Flip current image");
    flipImageButton.setActionCommand("Flip");
    flipImagePanel.add(flipImageButton);

    JPanel brightenImagePanel = new JPanel();
    brightenImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(brightenImagePanel);
    brightenImageButton = new JButton("Brighten/Darken current image");
    brightenImageButton.setActionCommand("Brighten");
    brightenImagePanel.add(brightenImageButton);

    JPanel blurImagePanel = new JPanel();
    blurImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(blurImagePanel);
    blurImageButton = new JButton("Blur current image");
    blurImageButton.setActionCommand("Blur");
    blurImagePanel.add(blurImageButton);

    JPanel sharpenImagePanel = new JPanel();
    sharpenImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(sharpenImagePanel);
    sharpenImageButton = new JButton("Sharpen current image");
    sharpenImageButton.setActionCommand("Sharpen");
    sharpenImagePanel.add(sharpenImageButton);

    JPanel sepiaImagePanel = new JPanel();
    sepiaImagePanel.setLayout(new FlowLayout());
    operationsPanel.add(sepiaImagePanel);
    sepiaImageButton = new JButton("Apply sepia filter to current image");
    sepiaImageButton.setActionCommand("Sepia");
    sepiaImagePanel.add(sepiaImageButton);

    JPanel listImagesPanel = new JPanel();
    listImagesPanel.setLayout(new FlowLayout());
    operationsPanel.add(listImagesPanel);
    listImagesButton = new JButton("List all loaded images");
    listImagesButton.setActionCommand("List");
    listImagesPanel.add(listImagesButton);
  }

  @Override
  public void setListener(ActionListener actionEvent) {
    imageSelectionBox.addActionListener(actionEvent);
    loadImageButton.addActionListener(actionEvent);
    saveImageButton.addActionListener(actionEvent);
    grayscaleImageButton.addActionListener(actionEvent);
    transformGrayscaleImageButton.addActionListener(actionEvent);
    vilImageButton.addActionListener(actionEvent);
    brightenImageButton.addActionListener(actionEvent);
    flipImageButton.addActionListener(actionEvent);
    blurImageButton.addActionListener(actionEvent);
    sharpenImageButton.addActionListener(actionEvent);
    sepiaImageButton.addActionListener(actionEvent);
    listImagesButton.addActionListener(actionEvent);
  }

  @Override
  public void renderMessage(String message) {
    this.outputTextArea.append(message + "\n");
  }

  @Override
  public void saveImage(String filePath, String imageName) throws IOException {
    if (this.model.findImage(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    model.Image img = this.model.findImage(imageName);
    String extension = filePath.substring(filePath.indexOf(".") + 1);

    if (extension.equalsIgnoreCase("ppm")) {
      FileWriter writer = new FileWriter(filePath);
      writer.write(img.toString());
      writer.close();
    } else {
      ImageIO.write(img.toBufferedImage(), extension, new File(filePath));
    }
  }

  @Override
  public String getCurrentImage() {
    return this.currentImage;
  }

  @Override
  public void setCurrentImage(String imageName) {
    this.currentImage = imageName;
  }

  @Override
  public void makeVisible() {
    this.setVisible(true);
  }

  @Override
  public void refresh() {
    if (this.currentImage == null) {
      imageLabel.setIcon(null);
    } else {
      model.Image modelImage = this.model.findImage(this.currentImage);
      Image img = modelImage.toBufferedImage();
      imageLabel.setIcon(new ImageIcon(img));
    }

    List<String> currentImages = model.getImageList();
    List<String> newImages = new ArrayList<String>();
    for (String i : currentImages) {
      if (!images.contains(i)) {
        newImages.add(i);
      }
    }
    for (int i = 0; i < newImages.size(); i++) {
      imageSelectionBox.addItem(newImages.get(i));
    }
    this.images = currentImages;

    this.histogramPanel.updateHist(this.model.findImage(this.currentImage));

    this.repaint();
    this.revalidate();
  }

  @Override
  public void simulateButtonActivation(String buttonName) {
    switch (buttonName) {
      case "load":
        loadImageButton.doClick();
        break;
      case "save":
        saveImageButton.doClick();
        break;
      case "grayscale":
        grayscaleImageButton.doClick();
        break;
      case "transform":
        transformGrayscaleImageButton.doClick();
        break;
      case "vil":
        vilImageButton.doClick();
        break;
      case "brighten":
        brightenImageButton.doClick();
        break;
      case "flip":
        flipImageButton.doClick();
        break;
      case "blur":
        blurImageButton.doClick();
        break;
      case "sharpen":
        sharpenImageButton.doClick();
        break;
      case "sepia":
        sepiaImageButton.doClick();
        break;
      case "list":
        listImagesButton.doClick();
        break;
      default:
        throw new IllegalArgumentException("Invalid command");
    }
  }
}
