package view;

import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * This class represents a mock version of the gui view for use in testing the gui controller and
 * all gui-related testing in general.
 */
public class ImageProcessingMockGUIView extends JFrame implements ImageProcessingGUIView {
  private StringBuilder log;
  private String currentImage;
  private final JButton loadImageButton;
  private final JButton saveImageButton;
  private final JButton grayscaleImageButton;
  private final JButton transformGrayscaleImageButton;
  private final JButton vilImageButton;
  private final JButton brightenImageButton;
  private final JButton flipImageButton;
  private final JButton blurImageButton;
  private final JButton sharpenImageButton;
  private final JButton sepiaImageButton;
  private final JButton listImagesButton;

  /**
   * Default constructor for the mock view for the graphical interface which takes in a log to
   * keep track of inputs.
   * @param log The log to keep track of inputs
   */
  public ImageProcessingMockGUIView(StringBuilder log) {
    loadImageButton = new JButton();
    loadImageButton.setActionCommand("Load");

    saveImageButton = new JButton();
    saveImageButton.setActionCommand("Save");

    grayscaleImageButton = new JButton();
    grayscaleImageButton.setActionCommand("Grayscale");

    transformGrayscaleImageButton = new JButton();
    transformGrayscaleImageButton.setActionCommand("Transform Grayscale");

    vilImageButton = new JButton();
    vilImageButton.setActionCommand("VIL");

    brightenImageButton = new JButton();
    brightenImageButton.setActionCommand("Brighten");

    flipImageButton = new JButton();
    flipImageButton.setActionCommand("Flip");

    blurImageButton = new JButton();
    blurImageButton.setActionCommand("Blur");

    sharpenImageButton = new JButton();
    sharpenImageButton.setActionCommand("Sharpen");

    sepiaImageButton = new JButton();
    sepiaImageButton.setActionCommand("Sepia");

    listImagesButton = new JButton();
    listImagesButton.setActionCommand("List");

    this.log = log;
  }

  @Override
  public void setListener(ActionListener actionEvent) {
    loadImageButton.addActionListener(actionEvent);
    saveImageButton.addActionListener(actionEvent);
    grayscaleImageButton.addActionListener(actionEvent);
    transformGrayscaleImageButton.addActionListener(actionEvent);
    vilImageButton.addActionListener(actionEvent);
    brightenImageButton.addActionListener(actionEvent);
    flipImageButton.addActionListener(actionEvent);
    blurImageButton.addActionListener(actionEvent);
    sharpenImageButton.addActionListener(actionEvent);
    sepiaImageButton.addActionListener(actionEvent);
    listImagesButton.addActionListener(actionEvent);
  }

  @Override
  public void renderMessage(String message) {
    this.log.append(message + "\n");
  }

  @Override
  public void saveImage(String filePath, String imageName) throws IOException {
    this.log.append("(save) filePath: " + filePath + ", imageName: " + imageName + "\n");
  }

  @Override
  public String getCurrentImage() {
    return this.currentImage;
  }

  @Override
  public void setCurrentImage(String imageName) {
    this.currentImage = imageName;
    this.log.append("(set) imageName: " + imageName + "\n");
  }

  @Override
  public void makeVisible() {
    this.setVisible(false);
  }

  @Override
  public void refresh() {
    this.log.append("");
  }

  @Override
  public void simulateButtonActivation(String buttonName) {
    switch (buttonName) {
      case "load":
        loadImageButton.doClick();
        break;
      case "save":
        saveImageButton.doClick();
        break;
      case "grayscale":
        grayscaleImageButton.doClick();
        break;
      case "transform":
        transformGrayscaleImageButton.doClick();
        break;
      case "vil":
        vilImageButton.doClick();
        break;
      case "brighten":
        brightenImageButton.doClick();
        break;
      case "flip":
        flipImageButton.doClick();
        break;
      case "blur":
        blurImageButton.doClick();
        break;
      case "sharpen":
        sharpenImageButton.doClick();
        break;
      case "sepia":
        sepiaImageButton.doClick();
        break;
      case "list":
        listImagesButton.doClick();
        break;
      default:
        throw new IllegalArgumentException("Invalid command");
    }
  }
}
