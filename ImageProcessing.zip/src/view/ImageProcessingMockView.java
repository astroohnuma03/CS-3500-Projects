package view;

import java.io.IOException;

/**
 * A mock version of the image processing view for use in testing the outputs of methods for the
 * controller.
 */
public class ImageProcessingMockView implements ImageProcessingView {
  private final StringBuilder log;

  /**
   * Default constructor for the mock view which takes in a StringBuilder log to keep track of
   * inputs.
   *
   * @param log The StringBuilder to keep track of view inputs
   */
  public ImageProcessingMockView(StringBuilder log) {
    if (log == null) {
      throw new IllegalArgumentException("log cannot be null");
    }
    this.log = log;
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.log.append("");
  }

  @Override
  public void saveImage(String filePath, String imageName) throws IOException {
    this.log.append("(save) filePath: " + filePath + ", imageName: " + imageName + "\n");
  }
}
