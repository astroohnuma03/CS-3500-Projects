package view;

import java.io.IOException;

/**
 * This interface represents the operations offered by the view of the image processing model.
 */
public interface ImageProcessingView {

  /**
   * Sends a text message to the view's appendable.
   *
   * @param message The text to be sent out
   */
  void renderMessage(String message) throws IOException;

  /**
   * Save the image with the given imageName to the given filePath.
   *
   * @param filePath  The path to save the file to
   * @param imageName The name of the file to be saved
   */
  void saveImage(String filePath, String imageName) throws IOException;
}
