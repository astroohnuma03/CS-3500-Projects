package view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.ImageIO;

import model.Image;
import model.ImageProcessingModel;

/**
 * Class which represents the implementation of the image processing view.
 */
public class ImageProcessingViewImpl implements ImageProcessingView {
  private ImageProcessingModel model;
  private Appendable destination;

  /**
   * Default constructor for the view which takes in a model and an appendable output location.
   *
   * @param model       The model to display with view
   * @param destination The place to send the appendable to
   */
  public ImageProcessingViewImpl(ImageProcessingModel model, Appendable destination) {
    this.model = model;
    this.destination = destination;
  }

  @Override
  public void saveImage(String filePath, String imageName)
          throws IllegalArgumentException, IOException {
    if (this.model.findImage(imageName) == null) {
      throw new IllegalArgumentException("Image not found.");
    }

    Image img = this.model.findImage(imageName);
    String extension = filePath.substring(filePath.indexOf(".") + 1);

    if (extension.equalsIgnoreCase("ppm")) {
      FileWriter writer = new FileWriter(filePath);
      writer.write(img.toString());
      writer.close();
    } else {
      ImageIO.write(img.toBufferedImage(), extension, new File(filePath));
    }
  }

  @Override
  public void renderMessage(String message) throws IOException {
    try {
      this.destination.append(message + "\n");
    } catch (IOException e) {
      throw new IllegalStateException("Appendable failed");
    }
  }
}
