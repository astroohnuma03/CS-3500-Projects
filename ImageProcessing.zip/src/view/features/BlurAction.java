package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the blur image method for the graphical interface.
 */
public class BlurAction extends JFrame implements ImageProcessingGUIViewActions {
  private final ImageProcessingModel model;
  private ImageProcessingGUIView view;

  /**
   * Default constructor for the BlurAction which takes in a model and a view and blurs the current
   * image in the graphical interface.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public BlurAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.model = model;
    this.view = view;
  }

  @Override
  public void runCommand() {
    String imageName = this.view.getCurrentImage();
    if (imageName == null) {
      JOptionPane.showMessageDialog(this, "Cannot blur if no image is" +
              " loaded!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
      String newImageName = "removeBlur";

      model.blur(imageName, newImageName);
      model.replaceImage(imageName, this.model.findImage(newImageName));
      model.removeImage(newImageName);
      view.renderMessage("Blurred " + imageName);
    }
  }
}
