package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the brightenImage method for the graphical interface.
 */
public class BrightenImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private int increment;
  private String imageName;
  private String newImageName;
  private ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default constructor for the BrightenImageAction which takes in a model and a view and
   * increments the brightness of an image by the user's input.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public BrightenImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.increment = 0;
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for the BrightenImageAction which takes in a model, view, and an increment to
   * simulate user input for testing.
   *
   * @param model     The model to use
   * @param view      The view to use
   * @param increment The amount to increment brightness by
   */
  public BrightenImageAction(ImageProcessingModel model, ImageProcessingGUIView view,
                             int increment) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.increment = increment;
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      this.imageName = this.view.getCurrentImage();
      this.newImageName = "removeBrighten";

      model.createBrightnessImage(this.increment, this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Brightened " + this.imageName + " by " + this.increment);
    } else {
      if (view.getCurrentImage() == null) {
        JOptionPane.showMessageDialog(this, "Cannot brighten if no image" +
                " is loaded!", "Error", JOptionPane.ERROR_MESSAGE);
      } else {
        try {
          increment = Integer.parseInt(JOptionPane.showInputDialog("Enter increment to brighten" +
                  "image by:"));

          this.imageName = this.view.getCurrentImage();
          this.newImageName = "removeBrighten";

          model.createBrightnessImage(this.increment, this.imageName, this.newImageName);
          model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
          model.removeImage(this.newImageName);
          view.renderMessage("Brightened " + this.imageName + " by " + this.increment);
        } catch (NumberFormatException e) {
          JOptionPane.showMessageDialog(BrightenImageAction.this,
                  "Please enter a valid number to increment brightness.", "Input Error",
                  JOptionPane.ERROR_MESSAGE);
        }
      }
    }
  }
}
