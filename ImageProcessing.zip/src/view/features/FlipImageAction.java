package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the create flipped image function for the graphical interface.
 */
public class FlipImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String verticalHorizontal;
  private String imageName;
  private String newImageName;
  private final ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default Constructor for FlipImageAction which takes in a model and view and flips the current
   * image on the axis chosen by the user.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public FlipImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.verticalHorizontal = "";
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for FlipImageAction which takes in a model, view, and a string which represents
   * the direction flipped to simulate user input.
   *
   * @param model              The model to use
   * @param view               The view to use
   * @param verticalHorizontal The direction to flip
   */
  public FlipImageAction(ImageProcessingModel model, ImageProcessingGUIView view,
                         String verticalHorizontal) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (verticalHorizontal == null) {
      throw new IllegalArgumentException("Flip input cannot be null");
    }

    this.verticalHorizontal = verticalHorizontal;
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      this.imageName = this.view.getCurrentImage();
      this.newImageName = "removeFlip";

      model.createFlippedImage(this.verticalHorizontal, this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Flipped " + this.imageName + " on it's " + this.verticalHorizontal +
              " axis");
    } else {
      if (view.getCurrentImage() == null) {
        JOptionPane.showMessageDialog(this, "Cannot flip with no image" +
                " loaded!", "Error", JOptionPane.ERROR_MESSAGE);
      } else {
        String[] flip = {"horizontal", "vertical"};
        int flipVal = JOptionPane.showOptionDialog(FlipImageAction.this,
                "Choose which way the image should be flipped:", "Flip Options",
                JOptionPane.YES_OPTION, JOptionPane.INFORMATION_MESSAGE, null, flip, flip[0]);

        if (flipVal != -1) {
          this.verticalHorizontal = flip[flipVal];
          this.imageName = this.view.getCurrentImage();
          this.newImageName = "removeFlip";

          model.createFlippedImage(this.verticalHorizontal, this.imageName, this.newImageName);
          model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
          model.removeImage(this.newImageName);
          view.renderMessage("Flipped " + this.imageName + " on it's " + this.verticalHorizontal +
                  " axis");
        }
      }
    }
  }
}
