package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the create grayscale image function for the graphical interface.
 */
public class GrayscaleImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String color;
  private String imageName;
  private String newImageName;
  private final ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default constructor for GrayscaleImageAction which takes in a model and view and grayscales
   * the current image by the color component selected by the user.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public GrayscaleImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.color = "";
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for GrayscaleImageAction which takes in a model, view, and string representing the
   * rgb color to grayscale by to simulate user input.
   *
   * @param model The model to use
   * @param view  The view to use
   * @param color The color to use
   */
  public GrayscaleImageAction(ImageProcessingModel model, ImageProcessingGUIView view,
                              String color) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (color == null) {
      throw new IllegalArgumentException("Color cannot be null");
    }

    this.color = color;
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      this.imageName = this.view.getCurrentImage();
      this.newImageName = "removeRGB";

      model.createGrayscale(this.color, this.imageName, this.newImageName);
      model.replaceImage(this.imageName, model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Grayscaled " + this.imageName + " via it's " + this.color + " component");
    } else {
      if (view.getCurrentImage() == null) {
        JOptionPane.showMessageDialog(this, "Cannot grayscale with no image"
                + " loaded!", "Error", JOptionPane.ERROR_MESSAGE);
      } else {
        String[] rgb = {"red", "green", "blue"};
        int colVal = JOptionPane.showOptionDialog(GrayscaleImageAction.this,
                "Choose RGB component to modify image:", "RGB Component Options",
                JOptionPane.YES_OPTION, JOptionPane.INFORMATION_MESSAGE, null, rgb, rgb[0]);

        if (colVal != -1) {
          this.color = rgb[colVal];
          this.imageName = this.view.getCurrentImage();
          this.newImageName = "removeRGB";

          model.createGrayscale(this.color, this.imageName, this.newImageName);
          model.replaceImage(this.imageName, model.findImage(this.newImageName));
          model.removeImage(this.newImageName);
          view.renderMessage("Grayscaled " + this.imageName + " via it's " + this.color
                  + " component");
        }
      }
    }
  }
}
