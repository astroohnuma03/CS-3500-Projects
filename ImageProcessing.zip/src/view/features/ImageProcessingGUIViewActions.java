package view.features;

/**
 * Interface which represents all the actions that can be performed by the graphical interface by
 * a user.
 */
public interface ImageProcessingGUIViewActions {

  /**
   * Runs this function object based on its implementation.
   */
  void runCommand();
}
