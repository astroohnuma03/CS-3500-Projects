package view.features;

import javax.swing.JComboBox;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the image selection menu in the graphical interface.
 */
public class ImageSelectionAction implements ImageProcessingGUIViewActions {
  private final JComboBox<String> imageSelectionBox;
  private final ImageProcessingGUIView view;

  /**
   * Default constructor which for ImageSelectionAction which takes in a model, view, and the image
   * selection box and selects a new current image based on the user's input.
   *
   * @param model             The model to use
   * @param view              The view to use
   * @param imageSelectionBox The combo box that represents image selection
   */
  public ImageSelectionAction(ImageProcessingModel model, ImageProcessingGUIView view,
                              JComboBox<String> imageSelectionBox) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (imageSelectionBox == null) {
      throw new IllegalArgumentException("Image Selection Box cannot be null");
    }

    this.imageSelectionBox = imageSelectionBox;
    this.view = view;
  }

  @Override
  public void runCommand() {
    String imageName = (String) this.imageSelectionBox.getSelectedItem();

    view.setCurrentImage(imageName);
    view.renderMessage("Selected " + imageName + " as current image");
  }
}
