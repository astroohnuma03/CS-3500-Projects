package view.features;

import javax.swing.JFrame;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function Object which represents the list image method for the graphical interface.
 */
public class ListImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private final ImageProcessingModel model;
  private final ImageProcessingGUIView view;

  /**
   * Default constructor which takes in a model and a view and prints a list of all images in the
   * model in the output text box.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public ListImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.model = model;
    this.view = view;
  }

  @Override
  public void runCommand() {
    view.renderMessage(model.toString());
  }
}
