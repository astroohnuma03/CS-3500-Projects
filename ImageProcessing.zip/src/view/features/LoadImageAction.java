package view.features;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the load image method for the graphical interface.
 */
public class LoadImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String fileName;
  private String imageName;
  private ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default constructor for LoadImageAction which takes in a model and view and loads a file
   * chosen by the user into the graphical interface with the user's given name.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public LoadImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.fileName = "";
    this.imageName = "";
    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for LoadImageAction which takes in a model, view, fileName, and imageName to
   * simulate user input.
   *
   * @param model     The model to use
   * @param view      The view to use
   * @param fileName  The file to use
   * @param imageName The name to set the image to
   */
  public LoadImageAction(ImageProcessingModel model, ImageProcessingGUIView view,
                         String fileName, String imageName) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (fileName == null) {
      throw new IllegalArgumentException("File name cannot be null");
    }
    if (imageName == null) {
      throw new IllegalArgumentException("Image name cannot be null");
    }

    this.fileName = fileName;
    this.imageName = imageName;
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      view.setCurrentImage(this.imageName);
      model.loadImage(this.fileName, this.imageName);
      view.renderMessage("Loaded new image file named " + this.imageName);
    } else {
      JFileChooser chooser = new JFileChooser(".");
      FileNameExtensionFilter filter = new FileNameExtensionFilter("PPM, PNG, JPG, and BMP"
              + " image files", "ppm", "png", "jpg", "bmp");
      chooser.setFileFilter(filter);
      int fileVal = chooser.showOpenDialog(LoadImageAction.this);
      if (fileVal == JFileChooser.APPROVE_OPTION) {
        fileName = chooser.getSelectedFile().getPath();
        imageName = JOptionPane.showInputDialog("Enter image name:");

        view.setCurrentImage(this.imageName);
        model.loadImage(this.fileName, this.imageName);
        view.renderMessage("Loaded new image file named " + this.imageName);
      }
    }
  }
}
