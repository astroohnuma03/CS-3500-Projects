package view.features;

import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the save image method for the graphical interface.
 */
public class SaveImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String fileWriter;
  private String imageName;
  private ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default constructor for SaveImageAction which takes in a model and view and saves the current
   * image in the graphical interface to the file path the user chooses.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public SaveImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for SaveImageAction which takes in a model, view, fileWriter, and imageName to
   * simulate user input for testing.
   *
   * @param model      The model to use
   * @param view       The view to use
   * @param fileWriter The file path to use
   * @param imageName  The image name to use
   */
  public SaveImageAction(ImageProcessingModel model, ImageProcessingGUIView view,
                         String fileWriter, String imageName) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (fileWriter == null) {
      throw new IllegalArgumentException("File path cannot be null");
    }
    if (imageName == null) {
      throw new IllegalArgumentException("Image name cannot be null");
    }

    this.fileWriter = fileWriter;
    this.imageName = imageName;
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      try {
        view.saveImage(this.fileWriter, this.imageName);
      } catch (IOException e) {
        throw new IllegalStateException("IO Failed.");
      }
      view.renderMessage("Saved " + this.imageName + " to " + this.fileWriter);
    } else {
      if (view.getCurrentImage() == null) {
        JOptionPane.showMessageDialog(this, "Cannot save image with no image"
                + "loaded!", "Error", JOptionPane.ERROR_MESSAGE);
      } else {
        JFileChooser chooser = new JFileChooser(".");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int dirVal = chooser.showSaveDialog(SaveImageAction.this);
        if (dirVal == JFileChooser.APPROVE_OPTION) {
          this.imageName = view.getCurrentImage();
          String[] ext = {"ppm", "png", "jpg", "bmp"};
          int extVal = JOptionPane.showOptionDialog(SaveImageAction.this,
                  "Choose extension type for image:", "Image Extension Options",
                  JOptionPane.YES_OPTION, JOptionPane.INFORMATION_MESSAGE, null, ext, ext[0]);

          if (extVal != -1) {
            this.fileWriter = chooser.getSelectedFile().getPath() + "\\" + this.imageName
                    + "." + ext[extVal];

            try {
              view.saveImage(this.fileWriter, this.imageName);
            } catch (IOException e) {
              throw new IllegalStateException("IO Failed.");
            }
            view.renderMessage("Saved " + this.imageName + " to " + this.fileWriter);
          }
        }
      }
    }
  }
}
