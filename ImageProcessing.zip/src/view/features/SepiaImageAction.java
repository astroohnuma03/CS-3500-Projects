package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the sepia image method for the graphical interface.
 */
public class SepiaImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String imageName;
  private String newImageName;
  private final ImageProcessingModel model;
  private final ImageProcessingGUIView view;

  /**
   * Default constructor which takes in a model and view and applies a sepia filter to the current
   * image in the graphical interface.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public SepiaImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
  }

  @Override
  public void runCommand() {
    this.imageName = view.getCurrentImage();
    if (this.imageName == null) {
      JOptionPane.showMessageDialog(this, "Cannot apply sepia filter with"
              + " no image loaded!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
      this.newImageName = "removeSepia";

      model.createSepiaImage(this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Sepia filter applied to " + this.imageName);
    }
  }
}
