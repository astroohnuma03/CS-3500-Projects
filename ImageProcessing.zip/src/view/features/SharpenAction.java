package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the sharpen method for the graphical interface.
 */
public class SharpenAction extends JFrame implements ImageProcessingGUIViewActions {
  private String imageName;
  private String newImageName;
  private final ImageProcessingModel model;
  private ImageProcessingGUIView view;

  /**
   * Default constructor for SharpenAction which takes in a model and view and sharpens the current
   * image in the graphical interface.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public SharpenAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
  }

  @Override
  public void runCommand() {
    this.imageName = this.view.getCurrentImage();
    if (this.imageName == null) {
      JOptionPane.showMessageDialog(this, "Cannot sharpen image with no"
              + " image loaded!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
      this.newImageName = "removeSharpen";

      model.sharpen(this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Sharpened " + this.imageName);
    }
  }
}
