package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the transform grayscale image method for the graphical
 * interface.
 */
public class TransformGrayscaleImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String imageName;
  private String newImageName;
  private ImageProcessingModel model;
  private ImageProcessingGUIView view;

  /**
   * Default constructor for TransformGrayscaleImageAction which takes in a model and view and
   * applies a grayscale filter to the current image.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public TransformGrayscaleImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
  }

  @Override
  public void runCommand() {
    this.imageName = this.view.getCurrentImage();
    if (this.imageName == null) {
      JOptionPane.showMessageDialog(this, "Cannot apply grayscale"
              + " transformation with no image loaded!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
      this.newImageName = "removeTransformGrayscale";

      model.createTransformGrayscale(this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Grayscale filter applied to " + this.imageName);
    }
  }
}
