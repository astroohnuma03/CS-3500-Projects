package view.features;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.ImageProcessingModel;
import view.ImageProcessingGUIView;

/**
 * Function object which represents the vil image method for the graphical interface.
 */
public class VILImageAction extends JFrame implements ImageProcessingGUIViewActions {
  private String vil;
  private String imageName;
  private String newImageName;
  private final ImageProcessingModel model;
  private ImageProcessingGUIView view;
  private boolean test;

  /**
   * Default constructor for the VILImageAction which takes in a model and view and visualizes the
   * current image by the brightness component selected by the user.
   *
   * @param model The model to use
   * @param view  The view to use
   */
  public VILImageAction(ImageProcessingModel model, ImageProcessingGUIView view) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }

    this.vil = "";
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = false;
  }

  /**
   * Constructor for the VILImageAction which takes in a model, view, and vil string to simulate
   * user input for testing.
   *
   * @param model The model to use
   * @param view  The view to use
   * @param vil   The visualization component to use
   */
  public VILImageAction(ImageProcessingModel model, ImageProcessingGUIView view, String vil) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    if (vil == null) {
      throw new IllegalArgumentException("VIL cannot be null");
    }

    this.vil = vil;
    this.imageName = "";
    this.newImageName = "";
    this.model = model;
    this.view = view;
    this.test = true;
  }

  @Override
  public void runCommand() {
    if (test) {
      this.imageName = this.view.getCurrentImage();
      this.newImageName = "removeVIL";

      model.createVILImage(this.vil, this.imageName, this.newImageName);
      model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
      model.removeImage(this.newImageName);
      view.renderMessage("Visualized " + this.imageName + " with " + this.vil);
    } else {
      if (view.getCurrentImage() == null) {
        JOptionPane.showMessageDialog(this, "Cannot visualize image with"
                + " no image loaded!", "Error", JOptionPane.ERROR_MESSAGE);
      } else {
        String[] vil = {"luma", "intensity", "value"};
        int vilVal = JOptionPane.showOptionDialog(VILImageAction.this,
                "Choose brightness component to visualize image with:",
                "Visualization Options", JOptionPane.YES_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, vil, vil[0]);

        if (vilVal != -1) {
          this.vil = vil[vilVal];
          this.imageName = this.view.getCurrentImage();
          this.newImageName = "removeVIL";

          model.createVILImage(this.vil, this.imageName, this.newImageName);
          model.replaceImage(this.imageName, this.model.findImage(this.newImageName));
          model.removeImage(this.newImageName);
          view.renderMessage("Visualized " + this.imageName + " with " + this.vil);
        }
      }
    }
  }
}
