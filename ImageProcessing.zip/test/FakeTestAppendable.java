import java.io.IOException;

/**
 * Class which represents a fake appendable that throws IOExceptions on all of its methods.
 */
public class FakeTestAppendable implements Appendable {
  @Override
  public Appendable append(CharSequence csq) throws IOException {
    throw new IOException("Appendable Failed");
  }

  @Override
  public Appendable append(CharSequence csq, int start, int end) throws IOException {
    throw new IOException("Appendable Failed");
  }

  @Override
  public Appendable append(char c) throws IOException {
    throw new IOException("Appendable Failed");
  }
}
