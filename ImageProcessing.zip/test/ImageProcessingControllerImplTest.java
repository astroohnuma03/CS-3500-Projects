import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;

import controller.ImageProcessingController;
import controller.ImageProcessingControllerImpl;
import model.ImageProcessingMockModel;
import model.ImageProcessingModel;
import model.ImageProcessingModelImpl;
import view.ImageProcessingMockView;
import view.ImageProcessingView;
import view.ImageProcessingViewImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Test class for the image processing controller.
 */
public class ImageProcessingControllerImplTest {

  // testing to make sure an exception is thrown when trying to create a controller with a null
  // model
  @Test
  public void testControllerConstructorExceptionNullModel() {
    Readable input = new StringReader("load Res/CuyValleyOriginal.ppm CuyValley");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);
    model = null;

    try {
      ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Provided model cannot be null", e.getMessage());
    }
  }

  // testing to make sure an exception is thrown when trying to create a controller with a null
  // view
  @Test
  public void testControllerConstructorExceptionNullView() {
    Readable input = new StringReader("load Res/CuyValleyOriginal.ppm CuyValley");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = null;

    try {
      ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Provided view cannot be null", e.getMessage());
    }
  }

  // testing to make sure an exception is thrown when trying to create a controller with a null
  // input
  @Test
  public void testControllerConstructorExceptionNullReadable() {
    Readable input = null;
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    try {
      ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Provided input cannot be null", e.getMessage());
    }
  }

  // testing that the load method receives inputs correctly
  @Test
  public void testControllerMockModelLoadMethod() {
    Readable input = new StringReader("load Res/CuyValleyOriginal.ppm CuyValley");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName: CuyValley\n",
            log.toString());
  }

  // testing that the save method receives inputs correctly
  @Test
  public void testControllerMockModelSaveMethod() {
    Readable input = new StringReader("save Res/CuyValleyModified.ppm CuyValleySaved");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    StringBuilder log2 = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingMockView(log2);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValleySaved");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName:" +
            " CuyValleySaved\n(save) filePath: Res/CuyValleyModified.ppm, imageName:" +
            " CuyValleySaved\n", log.toString() + log2);
  }

  // testing that the create grayscale image method receives inputs correctly
  @Test
  public void testControllerMockModelCreateGrayscaleMethod() {
    Readable input = new StringReader("grayscale red CuyValley CuyValleyRed");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
                    "(grayscale) color: red, imageName: CuyValley, newImageName: CuyValleyRed\n",
            log.toString());
  }

  // testing that the create vil image method receives inputs correctly
  @Test
  public void testControllerMockModelCreateVILMethod() {
    Readable input = new StringReader("vilImage value CuyValley CuyValleyValue");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
                    "(vil) vil: value, imageName: CuyValley, newImageName: CuyValleyValue\n",
            log.toString());
  }

  // testing that the create flipped image method receives inputs correctly
  @Test
  public void testControllerMockModelCreateFlippedMethod() {
    Readable input = new StringReader("flip horizontal CuyValley CuyValleyHorizFlip");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
                    "(flipped) vertHorz: horizontal, imageName: CuyValley, newImageName:" +
                    " CuyValleyHorizFlip\n",
            log.toString());
  }

  // testing that the create brightness image method receives inputs correctly
  @Test
  public void testControllerMockModelCreateBrightnessMethod() {
    Readable input = new StringReader("brightness 100 CuyValley CuyValley100Brighter");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: Res/CuyValleyOriginal.ppm, imageName:" +
            " CuyValley\n(brightness) incr: 100, imageName: CuyValley, newImageName:" +
            " CuyValley100Brighter\n", log.toString());
  }

  // testing that the blur method receives inputs correctly
  @Test
  public void testControllerMockModelBlurMethod() {
    Readable input = new StringReader("blur CuyValley CuyValleyBlur");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
            "(blur) imageName: CuyValley, newImageName: CuyValleyBlur\n", log.toString());
  }

  // testing that the sharpen method receives inputs correctly
  @Test
  public void testControllerMockModelSharpenMethod() {
    Readable input = new StringReader("sharpen CuyValley CuyValleySharpen");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
            "(sharpen) imageName: CuyValley, newImageName: CuyValleySharpen\n", log.toString());
  }

  // testing that the transform grayscale method receives inputs correctly
  @Test
  public void testControllerMockModelTransformGrayscaleMethod() {
    Readable input = new StringReader("grayscaleTransform CuyValley" +
            " CuyValleyTransformGrayscale");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: res/CuyValleyOriginal.ppm, imageName: CuyValley" +
            "\n(transform grayscale) imageName: CuyValley, newImageName:" +
            " CuyValleyTransformGrayscale\n", log.toString());
  }

  // testing that the transform sepia method receives inputs correctly
  @Test
  public void testControllerMockModelCreateSepiaMethod() {
    Readable input = new StringReader("sepia CuyValley CuyValleySepia");
    Appendable fakeOutput = new StringBuilder();
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingView view = new ImageProcessingViewImpl(model, fakeOutput);

    model.loadImage("res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    assertEquals("(load) fileName: res/CuyValleyOriginal.ppm, imageName: CuyValley\n" +
            "(sepia) imageName: CuyValley, newImageName: CuyValleySepia\n", log.toString());
  }

  // testing the load method and seeing if it outputs correctly
  @Test
  public void testControllerLoadMethodOutput() {
    Readable input = new StringReader("load Res/CuyValleyOriginal.ppm CuyValley");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Loaded image CuyValley from Res/CuyValleyOriginal.ppm", outputArr[0]);
  }

  // testing the save method and seeing if it outputs correctly
  @Test
  public void testControllerSaveMethodOutput() {
    Readable input = new StringReader("save Res/CuyValleySaved.ppm CuyValley");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Saved image CuyValley at Res/CuyValleySaved.ppm", outputArr[0]);
  }

  // testing the create grayscale image method by grayscaling an image with a red component and
  // seeing if it outputs correctly
  @Test
  public void testControllerCreateGrayscaleRedMethodOutput() {
    Readable input = new StringReader("grayscale red CuyValley CuyValleyRed");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyRed by red grayscaling CuyValley", outputArr[0]);
  }

  // testing the create grayscale image method by grayscaling an image with a green component and
  // seeing if it outputs correctly
  @Test
  public void testControllerCreateGrayscaleGreenMethodOutput() {
    Readable input = new StringReader("grayscale green CuyValley CuyValleyGreen");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyGreen by green grayscaling CuyValley", outputArr[0]);
  }

  // testing the create grayscale image method by grayscaling an image with a blue component and
  // seeing if it outputs correctly
  @Test
  public void testControllerCreateGrayscaleBlueMethodOutput() {
    Readable input = new StringReader("grayscale blue CuyValley CuyValleyBlue");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyBlue by blue grayscaling CuyValley", outputArr[0]);
  }

  // testing the create vil image method by visualizing an image with value and seeing if it
  // outputs correctly
  @Test
  public void testControllerCreateVILImageValueMethodOutput() {
    Readable input = new StringReader("vilImage value CuyValley CuyValleyValue");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyValue by Visualizing value brightness on CuyValley",
            outputArr[0]);
  }

  // testing the create vil image method by visualizing an image with intensity and seeing if it
  // outputs correctly
  @Test
  public void testControllerCreateVILImageIntensityMethodOutput() {
    Readable input = new StringReader("vilImage intensity CuyValley CuyValleyIntensity");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyIntensity by Visualizing intensity brightness on " +
            "CuyValley", outputArr[0]);
  }

  // testing the create vil image method by visualizing an image with luma and seeing if it outputs
  // correctly
  @Test
  public void testControllerCreateVILImageLumaMethodOutput() {
    Readable input = new StringReader("vilImage luma CuyValley CuyValleyLuma");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyLuma by Visualizing luma brightness on CuyValley",
            outputArr[0]);
  }

  // testing the create flipped image method by flipping an image horizontally and seeing if it
  // outputs correctly
  @Test
  public void testControllerCreateFlippedImageHorizMethodOutput() {
    Readable input = new StringReader("flip horizontal CuyValley CuyValleyHoriz");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyHoriz by horizontal flipping CuyValley", outputArr[0]);
  }

  // testing the create flipped image method by flipping an image vertically and seeing if it
  // outputs correctly
  @Test
  public void testControllerCreateFlippedImageVertMethodOutput() {
    Readable input = new StringReader("flip vertical CuyValley CuyValleyVert");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyVert by vertical flipping CuyValley", outputArr[0]);
  }

  // testing the create brightness image method by brightening by 100 and seeing if it outputs
  // correctly
  @Test
  public void testControllerCreateBrightnessImageBrightenMethodOutput() {
    Readable input = new StringReader("brightness 100 CuyValley CuyValley100Brighter");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValley100Brighter by brightening CuyValley by 100",
            outputArr[0]);
  }

  // testing the create brightness image method by darkening by 100 and seeing if it outputs
  // correctly
  @Test
  public void testControllerCreateBrightnessImageDarkenMethodOutput() {
    Readable input = new StringReader("brightness -100 CuyValley CuyValley100Darker");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValley100Darker by brightening CuyValley by -100",
            outputArr[0]);
  }

  // testing the list method to ensure that it outputs correctly
  @Test
  public void testControllerListMethodOutput() {
    Readable input = new StringReader("list");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");
    model.loadImage("Res/CuyValleyRedGrayscale.ppm", "CuyValleyRed");
    model.loadImage("Res/CuyValleyHorizFlip.ppm", "CuyValleyHorizFlip");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Images: CuyValley, CuyValleyRed, CuyValleyHorizFlip", outputArr[0]);
  }

  // testing the blur method to ensure that it outputs correctly
  @Test
  public void testControllerBlurImageMethodOutput() {
    Readable input = new StringReader("blur CuyValley CuyValleyBlur");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyBlur by blurring CuyValley", outputArr[0]);
  }

  // testing the sharpen method to ensure that it outputs correctly
  @Test
  public void testControllerSharpenImageMethodOutput() {
    Readable input = new StringReader("sharpen CuyValley CuyValleySharpen");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleySharpen by sharpening CuyValley", outputArr[0]);
  }

  // testing the transform grayscale method to ensure that it outputs correctly
  @Test
  public void testControllerTransformGrayscaleImageMethodOutput() {
    Readable input = new StringReader("grayscaleTransform CuyValley" +
            " CuyValleyTransformGrayscale");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleyTransformGrayscale by grayscaling CuyValley",
            outputArr[0]);
  }

  // testing the create sepia image method to ensure that it outputs correctly
  @Test
  public void testControllerCreateSepiaImageMethodOutput() {
    Readable input = new StringReader("sepia CuyValley CuyValleySepia");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Created CuyValleySepia by applying sepia to CuyValley", outputArr[0]);
  }

  // testing the controller to make sure that if an invalid command is given, the correct output
  // is shown
  @Test
  public void testControllerInvalidInputOutput() {
    Readable input = new StringReader("invalid");
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("Res/CuyValleyOriginal.ppm", "CuyValley");

    ImageProcessingController controller = new ImageProcessingControllerImpl(model, view, input);
    controller.runProgram();
    String[] outputArr = output.toString().split("\n");

    assertEquals("Invalid command. Try again.", outputArr[0]);
  }

  // testing to make sure that render message works correctly
  @Test
  public void testRenderMessage() {
    Appendable output = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);
    try {
      view.renderMessage("This is a test message! Hello!");
    } catch (IOException e) {
      throw new IllegalStateException("Appendable failed.");
    }

    assertEquals("This is a test message! Hello!\n", output.toString());
  }
}
