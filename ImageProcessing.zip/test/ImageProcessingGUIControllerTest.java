import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import controller.ImageProcessingGUIController;
import controller.ImageProcessingGUIControllerImpl;
import model.ImageProcessingMockModel;
import model.ImageProcessingModel;
import model.ImageProcessingModelImpl;
import view.ImageProcessingGUIView;
import view.ImageProcessingMockGUIView;
import view.features.BlurAction;
import view.features.BrightenImageAction;
import view.features.FlipImageAction;
import view.features.GrayscaleImageAction;
import view.features.ImageProcessingGUIViewActions;
import view.features.ListImageAction;
import view.features.LoadImageAction;
import view.features.SaveImageAction;
import view.features.SepiaImageAction;
import view.features.SharpenAction;
import view.features.TransformGrayscaleImageAction;
import view.features.VILImageAction;

import static org.junit.Assert.assertEquals;

/**
 * Test class for the GUI controller and all GUI related testing.
 */
public class ImageProcessingGUIControllerTest {

  @Test
  public void testMockGUIViewLoad() {
    StringBuilder log = new StringBuilder();
    StringBuilder log2 = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingMockModel(log);
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log2);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Load", new LoadImageAction(model, view, "res/testimages/rgb.ppm",
            "rgb"));

    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.simulateButtonActivation("load");
    assertEquals("(load) fileName: res/testimages/rgb.ppm, imageName: rgb\n",
            log.toString());
    assertEquals("(set) imageName: rgb\nLoaded new image file named rgb\n", log2.toString());
  }

  @Test
  public void testMockGUIViewSave() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Save", new SaveImageAction(model, view, "res/testimages/rgbSave.ppm",
            "rgb"));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.simulateButtonActivation("save");
    assertEquals("(save) filePath: res/testimages/rgbSave.ppm, imageName: rgb\n" +
            "Saved rgb to res/testimages/rgbSave.ppm\n", log.toString());
  }

  @Test
  public void testMockGUIViewGrayscale() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Grayscale", new GrayscaleImageAction(model, view, "red"));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("grayscale");
    assertEquals("(set) imageName: rgb\nGrayscaled rgb via it's red component\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewFlip() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Flip", new FlipImageAction(model, view, "horizontal"));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("flip");
    assertEquals("(set) imageName: rgb\nFlipped rgb on it's horizontal axis\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewVIL() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("VIL", new VILImageAction(model, view, "luma"));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("vil");
    assertEquals("(set) imageName: rgb\nVisualized rgb with luma\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewBrighten() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Brighten", new BrightenImageAction(model, view, 50));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("brighten");
    assertEquals("(set) imageName: rgb\nBrightened rgb by 50\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewTransformGrayscale() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Transform Grayscale", new TransformGrayscaleImageAction(model, view));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("transform");
    assertEquals("(set) imageName: rgb\nGrayscale filter applied to rgb\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewBlur() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Blur", new BlurAction(model, view));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("blur");
    assertEquals("(set) imageName: rgb\nBlurred rgb\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewSharpen() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Sharpen", new SharpenAction(model, view));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("sharpen");
    assertEquals("(set) imageName: rgb\nSharpened rgb\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewSepia() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("Sepia", new SepiaImageAction(model, view));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("sepia");
    assertEquals("(set) imageName: rgb\nSepia filter applied to rgb\n",
            log.toString());
  }

  @Test
  public void testMockGUIViewList() {
    StringBuilder log = new StringBuilder();
    ImageProcessingModel model = new ImageProcessingModelImpl();
    ImageProcessingGUIView view = new ImageProcessingMockGUIView(log);
    Map<String, ImageProcessingGUIViewActions> commands = new HashMap<>();
    commands.put("List", new ListImageAction(model, view));
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    ImageProcessingGUIController controller = new ImageProcessingGUIControllerImpl(model, view,
            commands);
    controller.runProgram();
    view.setCurrentImage("rgb");
    view.simulateButtonActivation("list");
    assertEquals("(set) imageName: rgb\nImages: rgb\n",
            log.toString());
  }
}