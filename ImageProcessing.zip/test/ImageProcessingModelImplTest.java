import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import model.Pixel;

import org.junit.Before;
import org.junit.Test;

import model.Image;
import model.ImageProcessingModel;
import model.ImageProcessingModelImpl;
import view.ImageProcessingView;
import view.ImageProcessingViewImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class represents testing for the image processing model.
 */
public class ImageProcessingModelImplTest {
  Image rgb;
  Image grayscaleRed;
  Image grayscaleGreen;
  Image grayscaleBlue;
  Image value;
  Image intensity;
  Image luma;
  Image flipHorizontal;
  Image flipVertical;
  Image brighter;
  Image darker;
  Image blur;
  Image sharpen;
  Image sepia;

  // Setting up the images as the model should create them.
  @Before
  public void setUp() {
    this.rgb = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(255, 0, 0),
            new Pixel(255, 0, 0),
            new Pixel(255, 0, 0)},
        new Pixel[]{
            new Pixel(0, 255, 0),
            new Pixel(0, 255, 0),
            new Pixel(0, 255, 0)},
        new Pixel[]{
            new Pixel(0, 0, 255),
            new Pixel(0, 0, 255),
            new Pixel(0, 0, 255)}});

    this.grayscaleRed = new Image(3, 3, 255,new Pixel[][]{
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)},
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)},
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)}});

    this.grayscaleGreen = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)},
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)},
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)}});

    this.grayscaleBlue = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)},
        new Pixel[]{
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0),
            new Pixel(0, 0, 0)},
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)}});

    this.value = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)},
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)},
        new Pixel[]{
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255),
            new Pixel(255, 255, 255)}});

    this.intensity = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85)},
        new Pixel[]{
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85)},
        new Pixel[]{
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85),
            new Pixel(85, 85, 85)}});

    this.luma = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(54, 54, 54),
            new Pixel(54, 54, 54),
            new Pixel(54, 54, 54)},
        new Pixel[]{
            new Pixel(182, 182, 182),
            new Pixel(182, 182, 182),
            new Pixel(182, 182, 182)},
        new Pixel[]{
            new Pixel(18, 18, 18),
            new Pixel(18, 18, 18),
            new Pixel(18, 18, 18)}});

    this.flipHorizontal = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(0, 0, 255),
            new Pixel(0, 255, 0),
            new Pixel(255, 0, 0)},
        new Pixel[]{
            new Pixel(0, 0, 255),
            new Pixel(0, 255, 0),
            new Pixel(255, 0, 0)},
        new Pixel[]{
            new Pixel(0, 0, 255),
            new Pixel(0, 255, 0),
            new Pixel(255, 0, 0)}});

    this.flipVertical = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(0, 0, 255),
            new Pixel(0, 0, 255),
            new Pixel(0, 0, 255)},
        new Pixel[]{
            new Pixel(0, 255, 0),
            new Pixel(0, 255, 0),
            new Pixel(0, 255, 0)},
        new Pixel[]{
            new Pixel(255, 0, 0),
            new Pixel(255, 0, 0),
            new Pixel(255, 0, 0)}});

    this.brighter = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(255, 50, 50),
            new Pixel(255, 50, 50),
            new Pixel(255, 50, 50)},
        new Pixel[]{
            new Pixel(50, 255, 50),
            new Pixel(50, 255, 50),
            new Pixel(50, 255, 50)},
        new Pixel[]{
            new Pixel(50, 50, 255),
            new Pixel(50, 50, 255),
            new Pixel(50, 50, 255)}});

    this.darker = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(205, 0, 0),
            new Pixel(205, 0, 0),
            new Pixel(205, 0, 0)},
        new Pixel[]{
            new Pixel(0, 205, 0),
            new Pixel(0, 205, 0),
            new Pixel(0, 205, 0)},
        new Pixel[]{
            new Pixel(0, 0, 205),
            new Pixel(0, 0, 205),
            new Pixel(0, 0, 205)}});

    this.blur = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(96, 48, 0),
            new Pixel(128, 64, 0),
            new Pixel(96, 48, 0)},
        new Pixel[]{
            new Pixel(48, 96, 48),
            new Pixel(64, 128, 64),
            new Pixel(48, 96, 48)},
        new Pixel[]{
            new Pixel(0, 48, 96),
            new Pixel(0, 64, 128),
            new Pixel(0, 48, 96)}});

    this.sharpen = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(255, 96, 0),
            new Pixel(255, 192, 0),
            new Pixel(255, 96, 0)},
        new Pixel[]{
            new Pixel(96, 255, 96),
            new Pixel(192, 255, 192),
            new Pixel(96, 255, 96)},
        new Pixel[]{
            new Pixel(0, 96, 255),
            new Pixel(0, 192, 255),
            new Pixel(0, 96, 255)}});

    this.sepia = new Image(3, 3, 255, new Pixel[][]{
        new Pixel[]{
            new Pixel(100, 89, 69),
            new Pixel(100, 89, 69),
            new Pixel(100, 89, 69)},
        new Pixel[]{
            new Pixel(196, 175, 136),
            new Pixel(196, 175, 136),
            new Pixel(196, 175, 136)},
        new Pixel[]{
            new Pixel(48, 43, 33),
            new Pixel(48, 43, 33),
            new Pixel(48, 43, 33)}});
  }

  // testing the load image method
  @Test
  public void testLoadImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");

    assertTrue(model.hasImage("rgb"));
  }

  // testing the load image method with a PNG file
  @Test
  public void testLoadPNG() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgbPNG.png", "rgb");

    assertTrue(model.hasImage("rgb"));
  }

  // testing the load image method with a JPG file
  @Test
  public void testLoadJPG() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgbJPG.jpg", "rgb");

    assertTrue(model.hasImage("rgb"));
  }

  // testing the load image method with a BMP file
  @Test
  public void testLoadBMP() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgbBMP.bmp", "rgb");

    assertTrue(model.hasImage("rgb"));
    assertEquals(this.rgb, model.findImage("rgb"));
  }

  // testing an exception for the load image method when the fileName and imageName are null
  @Test(expected = IllegalArgumentException.class)
  public void testLoadImageException() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage(null, null);
  }

  // testing the save image method
  @Test
  public void testSaveImage() throws IOException {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    Appendable output = new StringBuilder();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("res/testimages/rgb.ppm", "rgb");
    view.saveImage("res/testimages/rgb2.ppm", "rgb");
    model.loadImage("res/testimages/rgb2.ppm", "rgb2");

    assertTrue(model.hasImage("rgb2"));
  }

  // testing the save image method with a PNG
  @Test
  public void testSaveImagePNG() throws IOException {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    Appendable output = new StringBuilder();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("res/testimages/rgbPNG.png", "rgb");
    view.saveImage("res/testimages/rgb2PNG.png", "rgb");
    model.loadImage("res/testimages/rgb2PNG.png", "rgb2");

    assertTrue(model.hasImage("rgb2"));
  }

  // testing the save image method with a JPG
  @Test
  public void testSaveImageJPG() throws IOException {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    Appendable output = new StringBuilder();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("res/testimages/rgbJPG.jpg", "rgb");
    view.saveImage("res/testimages/rgb2JPG.jpg", "rgb");
    model.loadImage("res/testimages/rgb2JPG.jpg", "rgb2");

    assertTrue(model.hasImage("rgb2"));
  }

  // testing the save image method with a BMP
  @Test
  public void testSaveImageBMP() throws IOException {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    Appendable output = new StringBuilder();
    ImageProcessingView view = new ImageProcessingViewImpl(model, output);

    model.loadImage("res/testimages/rgbBMP.bmp", "rgb");
    view.saveImage("res/testimages/rgb2BMP.bmp", "rgb");
    model.loadImage("res/testimages/rgb2BMP.bmp", "rgb2");

    assertTrue(model.hasImage("rgb2"));
  }

  // testing the find image method
  @Test
  public void testFindImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");

    assertEquals(this.rgb, model.findImage("rgb"));
  }

  // testing the has image method
  @Test
  public void testHasImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");

    assertTrue(model.hasImage("rgb"));
  }

  @Test
  public void testGetImageList() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    List<String> list = new ArrayList<>();

    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.loadImage("res/testimages/GrayscaleRed.ppm", "redRGB");
    model.loadImage("res/testimages/GrayscaleBlue.ppm", "blueRGB");

    list.add("rgb");
    list.add("redRGB");
    list.add("blueRGB");

    for (String s : model.getImageList()) {
      assertTrue(list.contains(s));
    }
  }

  // testing the replaceImage method by replacing the value of an image and testing its new value
  @Test
  public void testReplaceImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.loadImage("res/testimages/GrayscaleRed.ppm", "redRGB");

    assertEquals(this.grayscaleRed, model.findImage("redRGB"));
    model.replaceImage("rgb", model.findImage("redRGB"));
    assertEquals(this.grayscaleRed, model.findImage("rgb"));
  }

  // testing the remove image method by checking if the imageMap contains an image after removing
  // it
  @Test
  public void testRemoveImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");

    assertTrue(model.hasImage("rgb"));
    model.removeImage("rgb");
    assertFalse(model.hasImage("rgb"));
  }

  // testing the create grayscale image method with a red component
  @Test
  public void testGrayscaleImageRed() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createGrayscale("red", "rgb", "redRGB");

    assertEquals(this.grayscaleRed, model.findImage("redRGB"));
  }

  // testing the create grayscale image method with a green component
  @Test
  public void testGrayscaleImageGreen() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createGrayscale("green", "rgb", "greenRGB");

    assertEquals(this.grayscaleGreen, model.findImage("greenRGB"));
  }

  // testing the create grayscale image method with a blue component
  @Test
  public void testGrayscaleImageBlue() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createGrayscale("blue", "rgb", "blueRGB");

    assertEquals(this.grayscaleBlue, model.findImage("blueRGB"));
  }

  // testing the create VIL image method with the value component
  @Test
  public void testVILImageValue() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createVILImage("value", "rgb", "valueRGB");

    assertEquals(this.value, model.findImage("valueRGB"));
  }

  // testing the create VIL image method with the intensity component
  @Test
  public void testVILImageIntensity() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createVILImage("intensity", "rgb", "intensityRGB");

    assertEquals(this.intensity, model.findImage("intensityRGB"));
  }

  // testing the create VIL image method with the luma component
  @Test
  public void testVILImageLuma() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createVILImage("luma", "rgb", "lumaRGB");

    assertEquals(this.luma, model.findImage("lumaRGB"));
  }

  // testing the create flipped image method by creating a horizontally flipped image
  @Test
  public void testFlippedImageHorizontal() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgbCol.ppm", "rgb");
    model.createFlippedImage("horizontal", "rgb",
        "horizontalRGB");

    assertEquals(this.flipHorizontal, model.findImage(
        "horizontalRGB"));
  }

  // testing the create flipped image method by creating a vertically flipped image
  @Test
  public void testFlippedImageVertical() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createFlippedImage("vertical", "rgb",
        "verticalRGB");

    assertEquals(this.flipVertical, model.findImage("verticalRGB"));
  }

  // testing the create brightness image method by brightening the image by 50
  @Test
  public void testBrightnessImageBrighten() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createBrightnessImage(50, "rgb", "brightenRGB");

    assertEquals(this.brighter, model.findImage("brightenRGB"));
  }

  // testing the create brightness image method by darkening the image by 50
  @Test
  public void testBrightnessImageDarken() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createBrightnessImage(-50, "rgb", "darkenRGB");

    assertEquals(this.darker, model.findImage("darkenRGB"));
  }

  // testing the list images method
  @Test
  public void testListImages() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.loadImage("res/testimages/GrayscaleRed.ppm", "redRGB");
    model.loadImage("res/testimages/rgbVertFlip.ppm", "verticalRGB");
    String list = "Images: rgb, redRGB, verticalRGB";

    assertEquals(list, model.toString());
  }

  // testing the blur method by blurring an image once
  @Test
  public void testBlurImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.blur("rgb", "blurRGB");

    assertEquals(this.blur, model.findImage("blurRGB"));
  }

  // testing the sharpen method by sharpening an image once
  @Test
  public void testSharpenImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.sharpen("rgb", "sharpRGB");

    assertEquals(this.sharpen, model.findImage("sharpRGB"));
  }

  // testing the color transformation grayscale method by grayscaling an image
  @Test
  public void testTransformGrayScale() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createTransformGrayscale("rgb", "grayscaleRGB");

    assertEquals(this.luma, model.findImage("grayscaleRGB"));
  }

  // testing the color transformation sepia method by applying a sepia filter to an image
  @Test
  public void testCreateSepiaImage() {
    ImageProcessingModel model = new ImageProcessingModelImpl();
    model.loadImage("res/testimages/rgb.ppm", "rgb");
    model.createSepiaImage("rgb", "sepiaRGB");

    assertEquals(this.sepia, model.findImage("sepiaRGB"));
  }
}